﻿using ArqLibrarianClassic.Library;
using ArqLibrarianClassic.Library.Catalogue;
using ArqLibrarianClassic.Library.Issues;
using ArqLibrarianClassic.Library.Ratings;
using ArqLibrarianClassic.Library.Users;

namespace ArqLibrarianClassic
{
    static class MainClass
    {
        public static void Main(string[] args)
        {
            var application = new Application();

            var booksDao = CreateBooksDao();
            CatalogueApplicationService catalogueApplicationService = new CatalogueApplicationService(booksDao);
            application.Setup(catalogueApplicationService);

            UserRepository userRepository = CreateMemoryUserRepository();
            UsersApplicationService usersApplicationService = new UsersApplicationService(userRepository);

            application.Setup(new IssuesApplicationService(
                usersApplicationService, catalogueApplicationService, CreateMemoryIssuesRepository(), new IssueFactory()));
            
            application.Setup(new RatingApplicationService(
                CreateMemoryRatingRepository(), new RatingFactory(usersApplicationService), 
                catalogueApplicationService, usersApplicationService));

            application.Setup(usersApplicationService);

            application.Start();
        }

        private static RatingRepository CreateMemoryRatingRepository()
        {
            var repository = new RatingRepository();
            repository.Init();

            return repository;
        }

        private static IssuesRepository CreateMemoryIssuesRepository()
        {
            var repository = new IssuesRepository();
            repository.Init();
            
            return repository;
        }

        private static UserRepository CreateMemoryUserRepository()
        {
            var repository = new UserRepository();
            repository.Init();
            return repository;
        }

        private static BooksRepository CreateBooksDao()
        {
            var repository = new BooksRepository();
            repository.Init();
            
            return repository;
        }
    }
}
