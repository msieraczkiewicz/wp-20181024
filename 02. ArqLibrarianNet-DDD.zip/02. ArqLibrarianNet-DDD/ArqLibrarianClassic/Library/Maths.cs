﻿using System;
namespace ArqLibrarianClassic.Library
{
    public class Maths
    {
        public static bool ComapareWithPrecision(double d1, double d2, double precision) 
        {
            return Math.Abs(d2 - d1) < precision;
        }
    }
}
