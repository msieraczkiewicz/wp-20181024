﻿using System;

namespace ArqLibrarianClassic.Library.Users
{
    public class UsersApplicationService
    {
        private UserRepository userRepository;

        public UsersApplicationService(UserRepository userRepository)
        {
            this.userRepository = userRepository;    
        }

        public string FindNickname(long userId)
        {
            return this.userRepository.FindNicknameBy(userId);
        }

        public string FindDescription(long userId)
        {
            var user = userRepository.FindById(userId);
            return user.Description();
        }

        public bool Exists(long issuingUserId)
        {
            return userRepository.Exists(issuingUserId);
        }
    }
}