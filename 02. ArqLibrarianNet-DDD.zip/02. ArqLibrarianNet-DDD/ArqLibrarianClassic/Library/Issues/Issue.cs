﻿using System;
using ArqLibrarianClassic.Library;
using ArqLibrarianClassic.Library.Catalogue;

namespace ArqLibrarianClassic.Library.Issues
{
    public class Issue
    {
        public long Id { get; set; }
        public long UserId { get; private set; }
        public long BookId { get; private set; }

        public string UserDescription { get; private set; }
        public string BookDescription { get; private set; }

        public DateTime When { get; private set; }
        private DateTime? returned = null;
        private readonly IssuePolicy policy;

        public Issue(long bookId, string bookDescription, long userId, string userDescription, IssuePolicy policy)
        {
            this.BookId = bookId;
            this.BookDescription = bookDescription;
            this.UserId = userId;
            this.UserDescription = userDescription;
            this.policy = policy;
            this.When = DateTime.Now;
        }

        public DateTime ExpectedReturn()
        {
            return policy.ReturnDate(When);
        }

        public bool Overdue() 
        {
            return policy.ReturnDate(When).CompareTo(DateTime.Now) > 0;
        }

        public bool Returned()
        {
            return returned.HasValue;
        }

        public void Return()
        {
            returned = DateTime.Now;
        }
    }
}