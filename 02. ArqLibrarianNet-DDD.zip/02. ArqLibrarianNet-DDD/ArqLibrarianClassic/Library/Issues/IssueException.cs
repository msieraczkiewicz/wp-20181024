﻿﻿using System;
using System.Runtime.Serialization;

namespace ArqLibrarianClassic.Library.Issues
{
    public class IssueException : Exception
    {
        public IssueException()
        {
        }

        public IssueException(string message) : base(message)
        {
        }

        public IssueException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected IssueException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}