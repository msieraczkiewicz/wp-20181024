﻿namespace ArqLibrarianClassic.Library.Issues
{
    public class Money
    {
        private int value;

        public Money(int value)
        {
            this.value = value;
        }
    }
}