﻿using System;
using System.Runtime.Serialization;
using ArqLibrarianClassic.Library;

namespace ArqLibrarianClassic.Library.Issues
{
    [Serializable]
    public class IssueTypeNotRecoginzedException : IssueException
    {
        public IssueTypeNotRecoginzedException()
        {
        }

        public IssueTypeNotRecoginzedException(string message) : base(message)
        {
        }

        public IssueTypeNotRecoginzedException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected IssueTypeNotRecoginzedException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}