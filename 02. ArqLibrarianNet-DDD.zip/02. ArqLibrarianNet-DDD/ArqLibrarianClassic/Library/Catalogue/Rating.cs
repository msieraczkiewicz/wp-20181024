﻿namespace ArqLibrarianClassic.Library.Catalogue
{
    public class Rating
    {
        private readonly double value;

        public Rating(double value)
        {
            this.value = value;
        }

        public override string ToString()
        {
            return (Maths.ComapareWithPrecision(value, -1.0, 0.0001) ? "not rated" : "" + value);
        }
    }
}