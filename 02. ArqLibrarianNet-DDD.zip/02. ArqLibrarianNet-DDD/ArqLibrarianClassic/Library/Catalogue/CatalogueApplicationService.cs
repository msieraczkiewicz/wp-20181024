﻿using System.Collections.Generic;

namespace ArqLibrarianClassic.Library.Catalogue
{
    public class CatalogueApplicationService
    {
        private readonly BooksRepository repository = null;

        public CatalogueApplicationService(BooksRepository dao)
        {
            this.repository = dao;
        }

        public IEnumerable<Book> FindAll()
        {
            return repository.FindAll();
        }

        public void AddBook(string title, string author, string isbn, string publisher, int year, string category)
        {    
            repository.Save(new Book(title, author, isbn, publisher, year, category));
        }

        public IEnumerable<Book> FindByTitle(string title)
        {
            return repository.FindByTitle(title);
        }

        public bool Exists(long bookId) 
        {
            return repository.Exists(bookId);
        }

        public string FindDescription(long bookId)
        {
            Book book = repository.FindById(bookId);
            return book.Description();
        }

        public Book FindById(long id)
        {
            return repository.FindById(id);
        }

        public void RatingChanged(long bookId, double rating)
        {
            Book book = repository.FindById(bookId);
            book.ChangeRating(rating);
            repository.Update(book);
        }
    }
}