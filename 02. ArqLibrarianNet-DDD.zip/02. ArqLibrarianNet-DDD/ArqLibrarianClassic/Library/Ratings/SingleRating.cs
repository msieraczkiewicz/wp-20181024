﻿﻿using System;

namespace ArqLibrarianClassic.Library.Ratings
{
    public class SingleRating
    {
        public int Value { get; }
        private DateTime when;
        private long userId;
        private string nickname;

        public SingleRating(long userId, string nickname, int value)
        {
            this.Value = value;
            this.when = DateTime.Now;
            this.userId = userId;
            this.nickname = nickname;
        }

        public RatingItem ToRatingItem()
        {
            return new RatingItem(Value, when, nickname);
        }

    }
}