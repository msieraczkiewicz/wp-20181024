﻿using System;

namespace ArqLibrarianClassic.Library.Ratings
{
    // DTO
    public class RatingItem
    {
        public int Value;
        public DateTime When;
        public string Nickname;

        public RatingItem(int value, DateTime when, string nickname)
        {
            this.Value = value;
            this.When = when;
            this.Nickname = nickname;
        }
    }
}