﻿using System;
using ArqLibrarianClassic.Library.Users;

namespace ArqLibrarianClassic.Library.Ratings
{
    public class RatingFactory
    {
        private UsersApplicationService usersApplicationService;

        public RatingFactory(UsersApplicationService usersApplicationService)
        {
            this.usersApplicationService = usersApplicationService;
        }
        
        public Rating Create(long bookId)
        {
            return new Rating(bookId);
        }
    }
}