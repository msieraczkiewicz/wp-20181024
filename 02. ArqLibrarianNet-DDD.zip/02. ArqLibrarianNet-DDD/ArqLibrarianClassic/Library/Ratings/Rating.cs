﻿using System;
using System.Collections.Generic;
using System.Linq;
using ArqLibrarianClassic.Library.Users;

namespace ArqLibrarianClassic.Library.Ratings
{
    public class Rating
    {
        public long BookId { get; set; }
        private List<SingleRating> singleRatings = new List<SingleRating>();

        public Rating(long bookId)
        {
            this.BookId = bookId;
        }

        public void Rate(long userId, string nickname, int value)
        {
            singleRatings.Add(new SingleRating(userId, nickname, value));
        }

        public double Value()
        {
            return singleRatings.Average(r => r.Value);
        }

        public RatingDetails ToDetails()
        {
            RatingDetails details = new RatingDetails();
            details.Value = Value();

            foreach (var rating in singleRatings) 
            {
                details.Add(rating.ToRatingItem());
            }

            return details;
        }
    }
}
