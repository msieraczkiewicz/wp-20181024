﻿using System;
using ArqLibrarianClassic.Library.Catalogue;
using ArqLibrarianClassic.Library.Users;

namespace ArqLibrarianClassic.Library.Ratings
{
    public class RatingApplicationService
    {
        private readonly RatingRepository repository;
        private readonly RatingFactory factory;
        private readonly CatalogueApplicationService catalogue;
        private readonly UsersApplicationService usersService;

        public RatingApplicationService(RatingRepository repository, RatingFactory factory, 
                                        CatalogueApplicationService catalogue, UsersApplicationService usersService)
        {
            this.repository = repository;
            this.factory = factory;
            this.catalogue = catalogue;
            this.usersService = usersService;
        }

        public void Rate(long bookId, long userId, int value)
        {
            Rating rating = repository.FindBy(bookId);

            if (rating == null)
            {
                rating = factory.Create(bookId);
                repository.Add(rating);
            }

            string nickname = usersService.FindNickname(userId);
            rating.Rate(userId, nickname, value);
            repository.Update(rating);

            // kind of event 
            catalogue.RatingChanged(bookId, rating.Value());
        }

        public double Rating(long bookId) 
        {
            Rating rating = repository.FindBy(bookId);

            if (rating == null) 
            {
                return -1.0;
            }

            return rating.Value();
        }

        public RatingDetails Details(long bookId) 
        {
            Rating rating = repository.FindBy(bookId);

            if (rating == null)
            {
                throw new RatingNotFoundException($"Ratings not found for book id = {bookId}");
            }

            return rating.ToDetails();
        }
    }
}
