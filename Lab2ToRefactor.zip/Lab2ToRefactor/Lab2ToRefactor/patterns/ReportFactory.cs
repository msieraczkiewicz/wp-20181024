﻿using System;

namespace Lab2ForRefactoring.bnsit.patterns
{
    public class ReportFactory
    {
        public ReportGenerator Create(string headerType, string bodyType, string footerType)
        {
            return new ReportGenerator(CreateHeaderGenerator(headerType), 
                                       CreateBodyGenerator(bodyType), 
                                       CreateFooterGenerator(footerType));
        }

        private HeaderGenerator CreateHeaderGenerator(string headerType)
        {
            if (headerType.Equals("indented"))
            {
                return new IndentedHeaderGenerator();
            }
            else if (headerType.Equals("tree")) 
            {
                return new TreeHeaderGenerator();
            }
            else if (headerType.Equals("dashed"))
            {
                return new DashedHeaderGenerator();
            }

            throw new Exception("Header type not supported: " + headerType);
        }

        private BodyGenerator CreateBodyGenerator(string bodyType)
        {
            if (bodyType.Equals("indented"))
            {
                return new IndentedBodyGenerator();
            }
            else if (bodyType.Equals("tree"))
            {
                return new TreeBodyGenerator();
            }
            else if (bodyType.Equals("dashed"))
            {
                return new DashedBodyGenerator();
            }

            throw new Exception("Body type not supported: " + bodyType);
        }

        private FooterGenerator CreateFooterGenerator(string footerType)
        {
            if (footerType.Equals("indented"))
            {
                return new IndentedFooterGenerator();
            }
            else if (footerType.Equals("tree"))
            {
                return new TreeFooterGenerator();
            }
            else if (footerType.Equals("dashed"))
            {
                return new DashedFooterGenerator();
            }

            throw new Exception("Footer type not supported: " + footerType);
        }

   }
}