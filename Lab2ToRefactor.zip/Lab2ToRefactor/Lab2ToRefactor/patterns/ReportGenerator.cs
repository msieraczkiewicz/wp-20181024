﻿using System;
using Lab2ForRefactoring.bnsit.patterns.model;

namespace Lab2ForRefactoring.bnsit.patterns
{
    public class ReportGenerator
    {
        private HeaderGenerator header;
        private BodyGenerator body;
        private FooterGenerator footer;

        public ReportGenerator(HeaderGenerator header, BodyGenerator body, FooterGenerator footer)
        {
            this.header = header;
            this.body = body;
            this.footer = footer;
        }

        public string Generate(ApplicationModel model)
        {
            return header.Generate(model) + body.Generate(model) + footer.Generate(model);
        }
    }
    public interface HeaderGenerator 
    {
        string Generate(ApplicationModel model);
    }
    public class IndentedHeaderGenerator : HeaderGenerator
    {
        public string Generate(ApplicationModel model) {
            return "Indented header";
        }
    }
    public class TreeHeaderGenerator : HeaderGenerator
    {
        private Format format;
        
        public string Generate(ApplicationModel model)
        {
            string header = format.Line() + format.NewLine(); // "******************************************************\n";
            header += format.Center("Building report") + format.NewLine();
            header += format.Line() + format.NewLine();
            return header;
        }
    }
    public class DashedHeaderGenerator : HeaderGenerator
    {
        public string Generate(ApplicationModel model)
        {
            string header = "------------------------------------------------------\n";
            header += "                  Building report                     \n";
            header += "------------------------------------------------------\n";
            header += "Total buildings: " + model.GetBuildingsCount() + "\n";
            header += "------------------------------------------------------\n";
            return header;
        }
    }
    public abstract class BodyGenerator
    {
        public abstract string Generate(ApplicationModel model);

        protected string Indent(string entry, string separator, int indentationLevel)
        {
            string indentation = "";

            for (int i = 0; i < indentationLevel; ++i)
            {
                indentation += separator;
            }

            return (indentation + entry + "\n");
        }
    }
    public class IndentedBodyGenerator : BodyGenerator
    {
        public override string Generate(ApplicationModel model)
        {
            return "Indented body";
        }
    }
    public class TreeBodyGenerator : BodyGenerator
    {
        public override string Generate(ApplicationModel model)
        {
            string report = "";

            foreach (Building building in model.Buildings)
            {
                report += Indent(building.Name + " ("
                        + building.Address + ")", "|-", 0);
                foreach (Elevation elevation in building.Elevations)
                {
                    report += Indent("Elevation " + elevation.Number, "|-", 1);
                    foreach (Room room in elevation.Rooms)
                    {
                        report += Indent("Room " + room.Number, "|-", 2);
                    }
                }
            }

            return report;
        }
    }
    public class DashedBodyGenerator : BodyGenerator
    {
        public override string Generate(ApplicationModel model)
        {
            string report = "";

            foreach (Building building in model.Buildings)
            {
                report += Indent(building.Name + " ("
                        + building.Address + ")", "--", 0);
                foreach (Elevation elevation in building.Elevations)
                {
                    report += Indent("Elevation " + elevation.Number, "--", 1);
                    foreach (Room room in elevation.Rooms)
                    {
                        report += Indent("Room " + room.Number, "--", 2);
                    }
                }
            }

            return report;
        }
    }
    public interface FooterGenerator
    {
        string Generate(ApplicationModel model);
    }
    public class IndentedFooterGenerator : FooterGenerator
    {
        public string Generate(ApplicationModel model)
        {
            return "Indented footer";
        }
    }

    public class TreeFooterGenerator : FooterGenerator
    {
        public string Generate(ApplicationModel model)
        {
            string date = DateTime.Now.ToString("dd/MM/yyyy");
            string footer = "****************" + date + "*******************\n";
            return footer;
        }
    }
    public class DashedFooterGenerator : FooterGenerator
    {
        public string Generate(ApplicationModel model)
        {
            string footer = "------------------------------------------------------\n";
            footer += "------------------------------------------------------\n";
            return footer;
        }
    }

}