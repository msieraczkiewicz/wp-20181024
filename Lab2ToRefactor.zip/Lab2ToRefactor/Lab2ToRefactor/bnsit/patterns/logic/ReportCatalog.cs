﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lab2ForRefactoring.bnsit.patterns.model;

namespace Lab2ForRefactoring.bnsit.patterns.logic
{
    class ReportCatalog
    {
        public static String DashedReport(ApplicationModel model) {
		String report = "";

		report += DashedHeader(model.Buildings.Count);

		foreach( Building building in model.Buildings ) {
			report += Body( building.Name + " ("
					+ building.Address + ")", "--", 0 );
			foreach( Elevation elevation in building.Elevations ) {
				report += Body( "Elevation " + elevation.Number, "--", 1 );
				foreach( Room room in elevation.Rooms ) {
					report += Body( "Room " + room.Number, "--", 2 );
				}
			}
		}

		report += DashedFooter();

		return report;
	}

        private static String DashedFooter()
        {
            String footer = "------------------------------------------------------\n";
            footer += "------------------------------------------------------\n";
            return footer;
        }

        private static String Body(String entry, String separator, int indentationLevel)
        {
            String indentation = "";

            for (int i = 0; i < indentationLevel; ++i)
            {
                indentation += separator;
            }

            return (indentation + entry + "\n");
        }

        private static String DashedHeader(int buildingsSize)
        {
            String header = "------------------------------------------------------\n";
            header += "                  Building report                     \n";
            header += "------------------------------------------------------\n";
            header += "Total buildings: " + buildingsSize + "\n";
            header += "------------------------------------------------------\n";
            return header;
        }

        public static String TreeReport(ApplicationModel model) {
		String report = "";

		report += TreeHeader();

		foreach( Building building in model.Buildings ) {
			report += Body( building.Name + " ("
					+ building.Address + ")", "|-", 0 );
			foreach( Elevation elevation in building.Elevations ) {
				report += Body( "Elevation " + elevation.Number, "|-", 1 );
				foreach( Room room in elevation.Rooms ) {
					report += Body( "Room " + room.Number, "|-", 2 );
				}
			}
		}

		report += TreeFooter();

		return report;
	}

        private static String TreeHeader()
        {
            String header = "******************************************************\n";
            header += "                   Building report                    \n";
            header += "******************************************************\n";
            return header;
        }

        private static String TreeFooter()
        {
            String date = DateTime.Now.ToString("dd/MM/yyyy");
            String footer = "****************" + date + "*******************\n";
            return footer;
        }

        public static String IndentedReport(ApplicationModel model)
        {
            return "I'm intended";
        }
    }
}
