﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lab1.bnsit.patterns.model;

namespace Lab1.bnsit.patterns
{
    class Application
    {
        private const String PROMPT = "ees>";
        private const String HELLO_MESSAGE = "Welcome to Equipment Evidence System!";

        private ApplicationModel model = new ApplicationModel();
        

        private Boolean running = false;

        public void Stop()
        {
            running = false;
        }

        public void Start()
        {
            running = true;

            System.Console.WriteLine(HELLO_MESSAGE);

            while (running)
            {
                System.Console.Write(PROMPT);
                String command = System.Console.ReadLine();

                if (command.Equals("hello"))
                {
                    System.Console.WriteLine(HELLO_MESSAGE);
                }
                else if (command.StartsWith("save"))
                {
                    String fileName = command.Split(' ')[1];
                    model.Save(fileName);
                }
                else if (command.StartsWith("load"))
                {
                    String fileName = command.Split(' ')[1];
                    model.Load(fileName);
                }
                else if (command.Equals("add_building"))
                {
                    AddBuilding();
                }
                else if (command.Equals("exit"))
                {
                    Stop();
                }
            }
        }

        private void AddBuilding()
        {
            Console.Write("Name: ");
            string name = Console.ReadLine();

            Console.Write("Address: ");
            string address = Console.ReadLine();

            Building building = new Building(name, address);

            Console.Write("First elevation number: ");
            int firstElevationNumber = int.Parse(Console.ReadLine());

            Console.Write("Last elevation number: ");
            int lastElevationNumber = int.Parse(Console.ReadLine());

            for (int i = firstElevationNumber; i <= lastElevationNumber; i++)
            {
                Elevation elevation = new Elevation(i);
                building.Add(elevation);

                Console.Write("Enter rooms for elevation: " + i);
                string [] roomsNumbers = Console.ReadLine().Split(' ');

                foreach (string roomNumberString in roomsNumbers)
                {
                    int roomNumber = int.Parse(roomNumberString);
                    Room room = new Room(roomNumber);
                    elevation.Add(room);
                }
            }

            model.AddBuilding(building);
        }

        static void Main(string[] args)
        {
            Application application = new Application();
            application.Start();
        }

    }
}
