﻿using System;
using Lab5ForRefactoring.bnsit.patterns.logic.command;
using Lab5ForRefactoring.bnsit.patterns.logic.command.log;

namespace Lab5ToRefactor
{
    abstract public class CommandDecorator : Command
    {
        protected readonly Logger logger = new Logger(typeof(CommandDecorator));

        protected readonly Command next;

        public CommandDecorator(Command command)
        {
            this.next = command;
        }

        public abstract void Execute(string param);

        public string Name 
        { 
            get 
            {
                return this.next.Name;
            }
        }
        public void PrintHelp() 
        {
            this.next.PrintHelp();
        }
    }

    public class InvocationLoggingDecorator : CommandDecorator
    {
        
        public InvocationLoggingDecorator(Command command) : base(command) { }

        public override void Execute(string param)
        {
            this.logger.LogDebug("Wykonanie komendy " + this.next.Name);

            this.next.Execute(param);

            this.logger.LogDebug("Zakończenie komendy: " + this.next.Name);
        }
    }

    public class TimeLoggingDecorator : CommandDecorator
    {
        public TimeLoggingDecorator(Command command) : base(command)
        {
        }

        public override void Execute(string param)
        {
            DateTime timeBegin = DateTime.Now;

            this.next.Execute(param);

            DateTime timeEnd = DateTime.Now;

            this.logger.LogDebug("Czas wykonania komendy " + this.next.Name + " = " + (timeEnd - timeBegin).Milliseconds + " ms.");
        }
    }

    public class ExceptionLoggingDecorator : CommandDecorator
    {
        public ExceptionLoggingDecorator(Command command) : base(command) { }

        public override void Execute(string param)
        {
            try
            {
                this.next.Execute(param);
            }
            catch (Exception e)
            {
                logger.LogDebug(e, "Komenda " + this.next.Name + " rzuciła wyjątek ");
            }
        }
    }
}
