﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lab5ForRefactoring.bnsit.patterns.model;
using Lab5ForRefactoring.bnsit.patterns.logic.report;
using Lab5ForRefactoring.bnsit.patterns.logic;
using Lab5ForRefactoring.bnsit.patterns.logic.command;
using Lab5ForRefactoring.bnsit.patterns.logic.command.log;
using Lab5ToRefactor;

namespace Lab5ForRefactoring.bnsit.patterns
{
    public class Application
    {
        private readonly Logger logger = new Logger(typeof(Application));

        private const String PROMPT = "ees>";

        private ApplicationModel model = new ApplicationModel();

        private Dictionary<string, Command> commands = new Dictionary<string, Command>();

        private Boolean running = false;

        public void Init()
        {
            Command helloCommand =
                new InvocationLoggingDecorator(
                    new ExceptionLoggingDecorator(
                        new TimeLoggingDecorator(new HelloCommand())));
            
            RegisterCommand(helloCommand);
            RegisterCommand(new SaveCommand(model));
            RegisterCommand(new LoadCommand(model));
            RegisterCommand(new AddBuildingCommand(model));
            RegisterCommand(new BuildingReportCommand(model));
            RegisterCommand(new ExitCommand(this));
            RegisterCommand(new HelpCommand(commands));
            RegisterCommand(new AddEquipmentCommand(model));
        }

        public void Stop()
        {
            running = false;
        }

        public void Start()
        {
            running = true;

            new HelloCommand().Execute(null);

            while (running)
            {
                Console.Write(PROMPT);
                string userCommand = Console.ReadLine();

                string[] commandAndParam = userCommand.Split(' ');
                string commandName = commandAndParam[0];

                bool unknownCommand = (!commands.ContainsKey(commandName));
                if (unknownCommand)
                {
                    Console.WriteLine("There's no command '" + commandName + "'");
                    continue;
                }

                bool hasParam = (commandAndParam.Length > 1);
                string param = null;
                if (hasParam)
                {
                    param = commandAndParam[1];
                }

                try
                {
                    commands[commandName].Execute(param);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Błąd krytyczny aplikacji. W logach znajdziesz więcej informacji. " + e.Message);
                }
            }
        }

        private void RegisterCommand(Command command)
        {
            commands.Add(command.Name, command);
        }

        static void Main(string[] args)
        {
            Application application = new Application();
            application.Init();
            application.Start();
        }
    }
}
