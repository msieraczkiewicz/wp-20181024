﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab5ForRefactoring.bnsit.patterns.model
{
    public class Table : Equipment
    {
        public Table() : base() { }
        public Table(string signature, int cost, DateTime purchaseDate) : base(signature, cost, purchaseDate) { }
    }
}
