﻿using System;
using Newtonsoft.Json;
using Trash.Model;

namespace Trash
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting");

            string json = @"{
                ""id"": 1, 
                ""title"": ""Karolcia"", 
                ""author"": ""Maria Kruger"", 
                ""isbn"": ""978-83-7568-638-8"", 
                ""publisher"": ""Siedmioróg"", 
                ""year"": 2011, 
                ""category"": ""Literatura dla dzieci i młodzieży"", 
                ""rating"": {
                    ""value"": 3}
                }";

            var book = JsonConvert.DeserializeObject<Book>(json);

            Console.WriteLine("Book: " + book);
            //Console.WriteLine("Starting client...");
            //CatalogueClient catalogue = new CatalogueClient();
            //Console.WriteLine("Client started...");

            //try
            //{
            //    var books = catalogue.FindAll().Result;
            //    foreach (var book in books)
            //    {
            //        Console.WriteLine(book);
            //    }
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e.InnerException.Message);
            //}

            //Console.WriteLine("Press Return when ready");
            //Console.ReadLine();
        }
    }
}
