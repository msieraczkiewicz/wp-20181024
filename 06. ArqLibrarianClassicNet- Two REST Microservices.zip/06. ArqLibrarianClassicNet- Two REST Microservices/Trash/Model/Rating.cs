﻿using System;
namespace Trash.Model
{
    public class Rating
    {
        public double Value { get; set; }

        public Rating(double value)
        {
            this.Value = value;
        }

        public override string ToString()
        {
            return (Value == -1.0 ? "not rated" : "" + Value);
        }
    }
}
