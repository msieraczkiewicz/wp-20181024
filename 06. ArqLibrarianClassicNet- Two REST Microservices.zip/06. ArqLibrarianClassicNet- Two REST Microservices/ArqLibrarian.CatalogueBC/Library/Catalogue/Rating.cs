﻿using Bnsit.ArqLibrarian.Library.Utils;

namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    public class Rating
    {
        public double Value { get; private set; }

        public Rating(double value)
        {
            this.Value = value;
        }

        public override string ToString()
        {
            return (Maths.ComapareWithPrecision(Value, -1.0, 0.0001) ? "not rated" : "" + Value);
        }
    }
}