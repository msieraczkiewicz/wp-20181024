﻿using System.Collections.Generic;

namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    public class BaseCatalogueApplicationService : CatalogueApplicationService
    {
        private readonly BookRepository repository = null;

        public BaseCatalogueApplicationService(BookRepository repository)
        {
            this.repository = repository;
        }

        public IEnumerable<BookDto> FindAll()
        {
            return BookDto.From(repository.FindAll());
        }

        public void AddBook(string title, string author, string isbn, string publisher, int year, string category)
        {    
            repository.Save(new Book(title, author, isbn, publisher, year, category));
        }

        public IEnumerable<BookDto> FindByTitle(string title)
        {
            return BookDto.From(repository.FindByTitle(title));
        }

        public bool Exists(long bookId) 
        {
            return repository.Exists(bookId);
        }

        public string FindDescription(long bookId)
        {
            Book book = repository.FindById(bookId);
            return book.Description();
        }

        public BookDto FindById(long id)
        {
            return BookDto.From(repository.FindById(id));
        }

        public void RatingChanged(RatingChangedEvent ratingChangedEvent)
        {
            Book book = repository.FindById(ratingChangedEvent.BookId);
            book.ChangeRating(ratingChangedEvent.Rating);
            repository.Update(book);
        }

        internal static IEnumerable<BookDto> From(IEnumerable<Book> books)
        {
            List<BookDto> dtos = new List<BookDto>();

            foreach (var book in books)
            {
                dtos.Add(From(book));
            }

            return dtos;
        }

        internal static BookDto From(Book book)
        {
            BookDto bookDto = new BookDto()
            {
                Id = book.Id,
                Title = book.Title,
                Author = book.Author,
                Isbn = book.Isbn,
                Publisher = book.Publisher,
                Year = book.Year,
                Category = book.Category,
                Rating = book.Rating.Value
            };

            return bookDto;
        }


    }
}