﻿namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    public class Book
    {
        public long Id { get; set; }
        public string Title { get; private set;}
        public string Author { get; private set; }
        public string Isbn { get; private set; }
        public string Publisher { get; private set; }
        public int Year { get; private set; }
        public string Category { get; private set; }
        public Rating Rating { get; private set; }
        
        public Book(string title, string author, string isbn, string publisher, int year, string category, double rating = -1.0)
        {
            this.Title = title;
            this.Author = author;
            this.Isbn = isbn;
            this.Publisher = publisher;
            this.Year = year;
            this.Category = category;
            this.Rating = new Rating(rating);
        }

        public void ChangeRating(double newValue)
        {
            this.Rating = new Rating(newValue);
        }

        public override string ToString()
        {
            return $"{this.Id}: '{this.Title}' - {this.Author} [{this.Isbn}] '{this.Publisher}', {this.Year}, '{this.Category}'" +
                $" {Rating.ToString()}";
        }

        public string RatingToString() 
        {
            return Rating.ToString();
        }

        public string Description()
        {
            return $"'{this.Title}' - {this.Author}";
        }
    }
}