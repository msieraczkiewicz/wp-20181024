﻿﻿using System;
using System.Runtime.Serialization;

namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    public class CatalogueException : Exception
    {
        public CatalogueException()
        {
        }

        public CatalogueException(string message) : base(message)
        {
        }

        public CatalogueException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected CatalogueException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}