﻿namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    public class BookNotFoundException : CatalogueException
    {
        public BookNotFoundException(string message) : base(message)
        {
        }
    }
}
