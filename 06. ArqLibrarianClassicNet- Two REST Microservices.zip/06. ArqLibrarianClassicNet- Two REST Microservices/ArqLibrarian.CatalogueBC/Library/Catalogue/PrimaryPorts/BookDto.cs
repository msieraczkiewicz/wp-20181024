﻿using System.Collections.Generic;

namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    public class BookDto
    {
        public long Id { get; set; }
        public string Title { get; set;}
        public string Author { get; set; }
        public string Isbn { get; set; }
        public string Publisher { get; set; }
        public int Year { get; set; }
        public string Category { get; set; }
        public double Rating { get; set; }

        internal static IEnumerable<BookDto> From(IEnumerable<Book> books)
        {
            List<BookDto> dtos = new List<BookDto>();

            foreach (var book in books)
            {
                dtos.Add(From(book));
            }

            return dtos;
        }

        internal static BookDto From(Book book)
        {
            BookDto bookDto = new BookDto()
            {
                Id = book.Id,
                Title = book.Title,
                Author = book.Author,
                Isbn = book.Isbn,
                Publisher = book.Publisher,
                Year = book.Year,
                Category = book.Category,
                Rating = book.Rating.Value
            };

            return bookDto;
        }

        public override string ToString()
        {
            return $"{this.Id}: '{this.Title}' - {this.Author} [{this.Isbn}] '{this.Publisher}', {this.Year}, '{this.Category}'" +
                $" {Rating}";
        }

    }
}