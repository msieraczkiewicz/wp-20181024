﻿using System.Collections.Generic;

namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    public interface BookRepository
    {
        void Save(Book book);

        IEnumerable<Book> FindAll();

        IEnumerable<Book> FindByTitle(string title);

        bool Exists(long bookId);

        Book FindById(long id);

        void Update(Book book);
    }
}