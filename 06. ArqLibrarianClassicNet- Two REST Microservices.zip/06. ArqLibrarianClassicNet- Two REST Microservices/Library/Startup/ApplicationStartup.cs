﻿
using NUnit.Framework;

namespace Bnsit.ArqLibrarian.Library.Startup
{
    public class ApplicationStartup
    {
        private BaseFixture fixture;

        [SetUp]
        public void SetupFixture()
        {
            this.fixture = new BaseFixture();
        }


        [Test()]
        public void ShouldShowHelloAtTheBegining()
        {
            fixture.ApplicationStarted();

            fixture.Then();
            fixture.SystemShows("Welcome to the ArqLibrarian");
        }
    }
}
