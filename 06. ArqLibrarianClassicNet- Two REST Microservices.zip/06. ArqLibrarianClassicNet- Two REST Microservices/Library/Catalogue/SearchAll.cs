﻿using NUnit.Framework;
using System;
namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    [TestFixture()]
    public class SearchAll
    {
        private BaseFixture fixture = null;

        [SetUp]
        public void SetupFixture()
        {
            fixture = new BaseFixture();
        }

        [Test]
        public void ShouldSearchAllBooks()
        {
            fixture.ApplicationStarted();

            fixture.UserEnters("search");

            fixture.Then();
            fixture.SystemShows(BaseFixture.Title("Karolcia"));
            fixture.SystemShows(BaseFixture.Author("Maria Kruger"));
            fixture.SystemShows(BaseFixture.Title("Renesans"));
            fixture.SystemShows(BaseFixture.Author("Jerzy Konieczny"));
            fixture.SystemShowsAtLeastLines(BaseFixture.StartBooksCount);
        }
    }
}
