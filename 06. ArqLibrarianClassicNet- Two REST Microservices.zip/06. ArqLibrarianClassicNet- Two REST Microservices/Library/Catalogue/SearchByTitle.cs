﻿using NUnit.Framework;
using System;
namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    [TestFixture()]
    public class SearchByTitle
    {
        private BaseFixture fixture = null;

        [SetUp]
        public void SetupFixture()
        {
            fixture = new BaseFixture();
        }

        [Test]
        public void ShouldSearchByTitle()
        {
            fixture.ApplicationStarted();

            fixture.HasBook("Ogniem i mieczem", "Henryk Sienkiewicz", "978-83-08-06015-5", "Wydawnictwo Literackie", 2016, "Podręczniki i lektury szkolne");

            //when
            fixture.UserEnters("search Ogniem i mieczem");

            fixture.Then();
            fixture.SystemShows("Found: 'Ogniem i mieczem'");
            fixture.SystemShows(BaseFixture.Title("Ogniem i mieczem"));
        }
    }
}
