﻿using NUnit.Framework;
using System;
namespace Bnsit.ArqLibrarian.Library.Issues
{
    [TestFixture()]
    public class IssueABook
    {
        private BaseFixture fixture = null;

        [SetUp]
        public void SetupFixture()
        {
            fixture = new BaseFixture();
        }

        [Test]
        public void ShouldIssueABook()
        {
            fixture.ApplicationStarted();

            fixture.HasBook("Ogniem i mieczem", "Henryk Sienkiewicz", "978-83-08-06015-5", "Wydawnictwo Literackie", 2016, "Podręczniki i lektury szkolne");
            var id = fixture.BookIdByTitle("Ogniem i mieczem");
            var userId = 1;
            var issueType = "normal";

            //when
                
            fixture.UserEnters($"issue {id} {userId} {issueType}");
            fixture.UserEnters($"status {id}");

            fixture.Then();
            fixture.SystemShows("[borrowed]*Ogniem i mieczem*");
        }

        [Test]
        public void ShouldShowStatusOfABook()
        {
            fixture.ApplicationStarted();

            fixture.HasBook("Ogniem i mieczem", "Henryk Sienkiewicz", "978-83-08-06015-5", "Wydawnictwo Literackie", 2016, "Podręczniki i lektury szkolne");
            var id = fixture.BookIdByTitle("Ogniem i mieczem");
            var userId = 1;
            var issueType = "normal";

            fixture.UserEnters($"status {id}");
            fixture.UserEnters($"issue {id} {userId} {issueType}");
            fixture.UserEnters($"status {id}");

            fixture.Then();
            fixture.SystemShows("[available]*Ogniem i mieczem*");
            fixture.SystemShows("[borrowed]*Ogniem i mieczem*");
        }
    }
}
