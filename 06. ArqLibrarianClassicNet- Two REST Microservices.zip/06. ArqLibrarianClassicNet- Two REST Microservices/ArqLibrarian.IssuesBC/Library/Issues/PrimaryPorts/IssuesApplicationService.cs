﻿using Bnsit.ArqLibrarian.Library.Catalogue;
using Bnsit.ArqLibrarian.Library.Users;

namespace Bnsit.ArqLibrarian.Library.Issues
{
    public interface IssuesApplicationService
    {
        void Issue(long userId, long bookId, string type);

        bool Issued(long bookId);

        void Return(long bookId);
    }
}