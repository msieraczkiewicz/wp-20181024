﻿namespace Bnsit.ArqLibrarian.Library.Issues
{
    public class IssueFactory
    {

        public Issue Create(long userId, string userDescription, long bookId, string bookDescription, string type)
        {
            return new Issue(bookId, bookDescription, userId, userDescription, CreateIssuePolicy(type));
        }

        private IssuePolicy CreateIssuePolicy(string termsType)
        {
            if (termsType.Equals("long"))
            {
                return new LongTermBorrowing();
            }
            else if (termsType.Equals("normal"))
            {
                return new NormalTermBorrowing();
            }
            else if (termsType.Equals("short"))
            {
                return new ShortTermBorrowing();
            }
            throw new IssueTypeNotRecoginzedException("Borrow terms not recoginzed: " + termsType);
        }
    }
}