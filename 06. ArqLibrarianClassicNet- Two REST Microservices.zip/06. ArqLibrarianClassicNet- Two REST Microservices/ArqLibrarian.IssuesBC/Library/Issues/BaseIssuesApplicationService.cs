﻿using Bnsit.ArqLibrarian.Library.Catalogue;
using Bnsit.ArqLibrarian.Library.Users;

namespace Bnsit.ArqLibrarian.Library.Issues
{
    public class BaseIssuesApplicationService : IssuesApplicationService
    {
        private readonly UsersApplicationService usersApplicationService;
        private readonly CatalogueApplicationService catalogueApplicationService;
        private readonly IssueRepository issuesRepository;
        private readonly IssueFactory factory;

        public BaseIssuesApplicationService(
            UsersApplicationService usersApplicationService, CatalogueApplicationService catalogueApplicationService, 
            IssueRepository issuesRepository, IssueFactory factory)
        {
            this.usersApplicationService = usersApplicationService;
            this.catalogueApplicationService = catalogueApplicationService;
            this.issuesRepository = issuesRepository;
            this.factory = factory;
        }

        public void Issue(long userId, long bookId, string type)
        {
            if (Issued(bookId)) 
            {
                throw new BookAlreadyIssuedException($"Book already issued with id = {bookId}");
            }

            var userDescription = usersApplicationService.FindDescription(userId);
            var bookDescription = catalogueApplicationService.FindDescription(bookId);
            Issue issue = factory.Create(userId, userDescription, bookId, bookDescription, type);

            issuesRepository.Save(issue);
        }

        public bool Issued(long bookId)
        {
            return issuesRepository.Exists(bookId);
        }

        public void Return(long bookId)
        {
            if (!Issued(bookId))
            {
                throw new BookNotIssuedException($"Book with id = {bookId} is not issued.");
            }
            
            Issue issue = issuesRepository.FindByBookId(bookId);

            issue.Return();

            issuesRepository.Update(issue);
        }

    }
}