﻿using System.Collections.Generic;
using System.Linq;
using Bnsit.ArqLibrarian.Library.Utils;

namespace Bnsit.ArqLibrarian.Library.Issues
{
    public class MemoryIssueRepository : IssueRepository
    {
        private static List<Issue> issues = new List<Issue>();
        
        public void Insert(Issue issue)
        {
            issue.Id = Generated.IssueId();
            issues.Add(issue);
        }

        public Issue FindByBookId(long id)
        {

            Issue issue = issues.FirstOrDefault(i => i.BookId == id);

            if (issue == null) {
                throw new IssueNotFoundException($"No issued found for book id = {id}");
            }

            return issue;
        }

        public bool Exists(long bookId)
        {
            return issues.Any(i => i.BookId == bookId && !i.Returned());
        }

        public void Init()
        {
            Clear();
            // no borrowings at start yet
        }

        public void Clear()
        {
            issues.Clear();
        }

        public void Save(Issue issue)
        {
            issues.Add(issue);
        }

        public void Update(Issue issue)
        {
            // nothing to be done, memory implementation
        }
    }
}