﻿using System;
using System.Runtime.Serialization;

namespace Bnsit.ArqLibrarian.Library.Issues
{
    [Serializable]
    public class IssueTypeNotRecoginzedException : IssueException
    {
        public IssueTypeNotRecoginzedException()
        {
        }

        public IssueTypeNotRecoginzedException(string message) : base(message)
        {
        }

        public IssueTypeNotRecoginzedException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected IssueTypeNotRecoginzedException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}