﻿namespace Bnsit.ArqLibrarian.Library.Issues
{
    public interface IssueRepository
    {
        void Insert(Issue issue);

        Issue FindByBookId(long id);

        bool Exists(long bookId);

        void Save(Issue issue);

        void Update(Issue issue);
    }
}