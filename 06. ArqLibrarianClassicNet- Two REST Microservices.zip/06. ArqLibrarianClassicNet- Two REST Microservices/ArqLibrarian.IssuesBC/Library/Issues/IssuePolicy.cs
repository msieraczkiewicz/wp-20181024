﻿using System;

namespace Bnsit.ArqLibrarian.Library.Issues
{
    public interface IssuePolicy
    {
        DateTime ReturnDate(DateTime start);
        Money Fine(DateTime start, DateTime end);
        String Type();
    }

    public class ShortTermBorrowing : IssuePolicy
    {
        public Money Fine(DateTime start, DateTime end)
        {
            return new Money(100);
        }

        public DateTime ReturnDate(DateTime start)
        {
            return start.AddDays(3.0);
        }

        public string Type()
        {
            return "short";
        }
    }

    public class NormalTermBorrowing : IssuePolicy
    {
        public Money Fine(DateTime start, DateTime end)
        {
            return new Money(10);
        }

        public DateTime ReturnDate(DateTime start)
        {
            return start.AddDays(30.0);
        }

        public string Type()
        {
            return "normal";
        }
    }

    public class LongTermBorrowing : IssuePolicy
    {
        public Money Fine(DateTime start, DateTime end)
        {
            return new Money(5);
        }

        public DateTime ReturnDate(DateTime start)
        {
            return start.AddDays(60.0);
        }

        public string Type()
        {
            return "long";
        }
    }
}