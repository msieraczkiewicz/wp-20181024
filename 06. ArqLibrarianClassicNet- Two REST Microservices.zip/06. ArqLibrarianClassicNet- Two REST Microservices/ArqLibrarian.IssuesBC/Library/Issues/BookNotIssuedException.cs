﻿using System;
using System.Runtime.Serialization;

namespace Bnsit.ArqLibrarian.Library.Issues
{
    [Serializable]
    internal class BookNotIssuedException : IssueException
    {
        public BookNotIssuedException()
        {
        }

        public BookNotIssuedException(string message) : base(message)
        {
        }

        public BookNotIssuedException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected BookNotIssuedException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}