﻿using System;
using System.Runtime.Serialization;

namespace Bnsit.ArqLibrarian.Library.Issues
{
    [Serializable]
    public class IssueNotFoundException : IssueException
    {
        public IssueNotFoundException()
        {
        }

        public IssueNotFoundException(string message) : base(message)
        {
        }

        public IssueNotFoundException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected IssueNotFoundException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}