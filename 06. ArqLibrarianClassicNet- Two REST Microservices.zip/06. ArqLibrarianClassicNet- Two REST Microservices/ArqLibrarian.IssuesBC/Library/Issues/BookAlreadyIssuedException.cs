﻿using System;
using System.Runtime.Serialization;

namespace Bnsit.ArqLibrarian.Library.Issues
{
    [Serializable]
    internal class BookAlreadyIssuedException : IssueException
    {
        public BookAlreadyIssuedException()
        {
        }

        public BookAlreadyIssuedException(string message) : base(message)
        {
        }

        public BookAlreadyIssuedException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected BookAlreadyIssuedException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}