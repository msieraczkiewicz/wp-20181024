﻿using System;
using System.Runtime.Serialization;

namespace ArqLibrarian.Catalogue.RestClient
{
    [Serializable]
    internal class CatalogueClientException : Exception
    {
        public CatalogueClientException()
        {
        }

        public CatalogueClientException(string message) : base(message)
        {
        }

        public CatalogueClientException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected CatalogueClientException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}