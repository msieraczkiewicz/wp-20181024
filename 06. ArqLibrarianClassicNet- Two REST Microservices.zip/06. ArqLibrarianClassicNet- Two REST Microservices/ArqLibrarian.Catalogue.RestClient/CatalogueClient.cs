﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ArqLibrarian.UtilsCore.Rest;
using Bnsit.ArqLibrarian.Library.Catalogue;

namespace ArqLibrarian.Catalogue.RestClient
{
    public class CatalogueClient
    {
        private RestJsonClient http;

        public CatalogueClient(RestJsonClient http)
        {
            this.http = http;
        }

        public async Task<IEnumerable<BookDto>> FindAll()
        {
            return await http.GetAsync<IEnumerable<BookDto>, CatalogueClientException>($"/api/catalogue/books");
        }

        public async Task<IEnumerable<BookDto>> FindByTitle(string title)
        {
            return await http.GetAsync<IEnumerable<BookDto>, CatalogueClientException>($"/api/catalogue/books?title={title}");           
        }

        public async Task<BookDto> FindById(long bookId)
        {
            return await http.GetAsync<BookDto, CatalogueClientException>($"/api/catalogue/books/{bookId}");
        }

        public async Task<bool> Exists(long bookId)
        {
            return await http.GetAsync<bool, CatalogueClientException>($"/api/catalogue/books/{bookId}/exists");
        }

        public async Task AddBook(BookDto book)
        {
            await http.PostAsync<CatalogueClientException>($"/api/catalogue/books", book);
        }

        public async Task RatingChanged(RatingChangedEvent ratingChangedEvent)
        {
            await http.PutAsync<CatalogueClientException>($"/api/catalogue/books/rating-changed", ratingChangedEvent);
        }
    }
}
