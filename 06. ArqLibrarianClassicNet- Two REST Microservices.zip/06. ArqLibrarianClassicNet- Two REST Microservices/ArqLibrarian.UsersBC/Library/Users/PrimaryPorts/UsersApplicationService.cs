﻿using System;

namespace Bnsit.ArqLibrarian.Library.Users
{
    public interface UsersApplicationService
    {
        string FindNickname(long userId);

        string FindDescription(long userId);

        bool Exists(long issuingUserId);
    }
}