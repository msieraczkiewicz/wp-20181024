﻿namespace Bnsit.ArqLibrarian.Library.Users
{
    public class BaseUsersApplicationService : UsersApplicationService
    {
        private UserRepository userRepository;

        public BaseUsersApplicationService(UserRepository userRepository)
        {
            this.userRepository = userRepository;    
        }

        public string FindNickname(long userId)
        {
            return this.userRepository.FindNicknameBy(userId);
        }

        public string FindDescription(long userId)
        {
            var user = userRepository.FindById(userId);
            return user.Description();
        }

        public bool Exists(long issuingUserId)
        {
            return userRepository.Exists(issuingUserId);
        }
    }
}