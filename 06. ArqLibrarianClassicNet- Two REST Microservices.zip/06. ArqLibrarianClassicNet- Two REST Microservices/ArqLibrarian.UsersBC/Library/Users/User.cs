﻿﻿namespace Bnsit.ArqLibrarian.Library.Users
{
    public class User
    {
        public long Id { get; set; }
        public string Nickname { get; private set; }
        public string Password { get; private set; }
        public string Fullname { get; private set; }
        public string Address { get; private set; }
        public string Pesel { get; private set; }

        public User(string nickname, string password, string fullname, string address, string pesel)
        {
            this.Nickname = nickname;
            this.Password = password;
            this.Fullname = fullname;
            this.Address = address;
            this.Pesel = pesel;
        }

        public string Description()
        {
            return $"{Fullname} ({Nickname})";
        }
    }
}