﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bnsit.ArqLibrarian.Library.Utils;

namespace Bnsit.ArqLibrarian.Library.Users
{
    public class MemoryUserRepository : UserRepository
    {
        private static readonly List<User> users = new List<User>();

        public void Save(User user)
        {
            user.Id = Generated.UserId();
            users.Add(user);
        }

        public string FindNicknameBy(long userId)
        {
            var nickname = users.Where(u => u.Id == userId)
                                .Select(u => u.Nickname)
                                .FirstOrDefault();

            if (nickname == null)
            {
                throw new UserException($"User not found with id = {userId}");
            }

            return nickname;
        }

        public bool Exists(long issuingUserId)
        {
            return users.Any(u => u.Id == issuingUserId);
        }

        public User FindById(long id)
        {
            var user = users.FirstOrDefault(u => u.Id == id);

            if (user == null)
            {
                throw new UserException($"User not found with id = {id}");
            }

            return user;
        }

        public void Init()
        {
            Clear();
            Save(new User("kowalski", "kowal", "Jan Kowalski", "Gdynia", "87052507754"));
            Save(new User("nowak", "nowypass", "Piotr Nowak", "Warszawa", "890224031121"));
            Save(new User("koper", "dupadupa", "Wojciech Koperski", "Zakopane", "91121202176"));
        }

        public void Clear()
        {
            users.Clear();
        }
    }
}