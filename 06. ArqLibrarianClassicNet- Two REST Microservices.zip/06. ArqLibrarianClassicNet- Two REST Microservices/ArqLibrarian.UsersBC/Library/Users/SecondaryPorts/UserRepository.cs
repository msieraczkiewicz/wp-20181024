﻿namespace Bnsit.ArqLibrarian.Library.Users
{
    public interface UserRepository
    {
        void Save(User user);

        string FindNicknameBy(long userId);

        bool Exists(long issuingUserId);

        User FindById(long id);

    }
}