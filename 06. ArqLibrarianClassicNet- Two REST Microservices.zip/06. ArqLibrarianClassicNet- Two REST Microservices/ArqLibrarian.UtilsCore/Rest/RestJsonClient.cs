﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace ArqLibrarian.UtilsCore.Rest
{
    public class RestJsonClient
    {
        private HttpClient http = new HttpClient();

        public RestJsonClient(string baseAddress)
        {
            
            this.http.BaseAddress = new Uri(baseAddress);
            this.http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task<T> GetAsync<T,E>(string uri) where E : Exception
        {
            HttpResponseMessage response = await http.GetAsync(uri);

            if (response.IsSuccessStatusCode)
            {
                string resultString = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<T>(resultString);
            }

            string errorMessage = await response.Content.ReadAsStringAsync();
            // throw an exception
            throw Activator.CreateInstance(typeof(E), errorMessage) as E;
        }

        public async Task PostAsync<E>(string uri, object request) where E : Exception
        {
            
            HttpResponseMessage response = await this.http.PostAsJsonAsync(uri, request);

            if (response.IsSuccessStatusCode)
            {
                return;
            }

            string errorMessage = await response.Content.ReadAsStringAsync();
            // throw an exception
            throw Activator.CreateInstance(typeof(E), errorMessage) as E;
        }

        public async Task PutAsync<E>(string uri, object request) where E : Exception
        {

            HttpResponseMessage response = await this.http.PutAsJsonAsync(uri, request);

            if (response.IsSuccessStatusCode)
            {
                return;
            }

            string errorMessage = await response.Content.ReadAsStringAsync();
            // throw an exception
            throw Activator.CreateInstance(typeof(E), errorMessage) as E;
        }

    }
}
