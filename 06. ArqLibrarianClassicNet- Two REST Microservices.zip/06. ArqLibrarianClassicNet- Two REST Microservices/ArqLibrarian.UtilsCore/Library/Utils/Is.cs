﻿using System;
using System.Linq;

namespace Bnsit.ArqLibrarian.Library.Utils
{
    public class Is
    {
        public static bool NumberNotBetween(string arg, int bootom, int upper, string message)
        {
            var number = int.Parse(arg);
            if (number < 1 || number > 5)
            {
                Console.WriteLine($"Rating should be a number between 1 and 5.");
                return true;
            }

            return false;
        }

        public static bool NotNumber(string arg, string message)
        {
            if (!arg.All(Char.IsDigit))
            {
                Console.WriteLine(message);
                return true;
            }

            return false;
        }

        public static bool NotValidLength(string[] strings, int length, string message)
        {
            if (strings.Length != length)
            {
                Console.WriteLine(message);
                return true;
            }

            return false;
        }

        public static bool StringNotIn(string element, string[] array, string message)
        {
            if (!array.Contains(element))
            {
                Console.WriteLine(message);
                return true;
            }
                
            return false;
        }
    }
}
