﻿using System;
using ArqLibrarian.Catalogue.RestClient;
using ArqLibrarian.UtilsCore.Rest;
using Bnsit.ArqLibrarian.Library.Catalogue;

namespace ArqLibrarian.Catalogue.RestClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting client...");
            CatalogueClient catalogue
                = new CatalogueClient(new RestJsonClient("http://localhost:5001"));
            Console.WriteLine("Client started...");

            try
            {
                for (int i = 1; i <= 5; i++)
                {
                    var book = catalogue.FindById(i).Result;
                    Console.WriteLine(book + " exists:" + catalogue.Exists(i).Result);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.InnerException.Message);
            }

            catalogue.AddBook(new BookDto()
            {
                Title = "Krzyżacy",
                Author = "Henryk Sienkiewicz",
                Isbn = "978-83-01-15409-8",
                Publisher = "Znak",
                Year = 2015,
                Category = "Powieści historyczne"
            }).Wait();

            Console.WriteLine("==================");
            PrintAllBooks(catalogue);

            Console.WriteLine("Change rating");
            catalogue.RatingChanged(new RatingChangedEvent(1, 4)).Wait();

            Console.WriteLine("==================");
            PrintAllBooks(catalogue);

            Console.WriteLine("Press Return when ready");
            Console.ReadLine();
        }

        private static void PrintAllBooks(CatalogueClient catalogue)
        {
            var books = catalogue.FindAll().Result;
            foreach (var book in books)
            {
                Console.WriteLine(book);
            }
        }
    }
}
