﻿using Microsoft.AspNetCore.Mvc;
using Bnsit.ArqLibrarian.Library.Users;

namespace ArqLibrarian.Users.Rest.Controllers
{
    [Route("api/[controller]")]
    public class UsersController : Controller
    {
        private UsersApplicationService usersService;

        public UsersController(UsersApplicationService usersService)
        {
            this.usersService = usersService;
        }

        [HttpGet]
        [Route("{userId:long}/nickname")]
        public IActionResult FindNickname(long userId)
        {
            string nickname = "";
            try
            {
                nickname = this.usersService.FindNickname(userId);
            }
            catch (UserException e)
            {
                return NotFound(e.Message);
            }

            return Ok(nickname);
        }

        [HttpGet]
        [Route("{userId:long}/description")]
        public IActionResult FindDescription(long userId)
        {
            string description = "";
            try
            {
                description = this.usersService.FindDescription(userId);
            }
            catch (UserException e)
            {
                return NotFound(e.Message);
            }

            return Ok(description);
        }

        [HttpGet]
        [Route("{userId:long}/exists")]
        public IActionResult Exists(long userId)
        {
            bool exists = false;
            try
            {
                exists = this.usersService.Exists(userId);
            }
            catch (UserException e)
            {
                return NotFound(e.Message);
            }

            return new OkObjectResult(exists);            
        }
    }
}
