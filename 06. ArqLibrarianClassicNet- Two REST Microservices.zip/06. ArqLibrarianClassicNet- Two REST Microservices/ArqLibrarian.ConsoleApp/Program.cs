﻿using Bnsit.ArqLibrarian.Library.ConsoleUI;
using Bnsit.ArqLibrarian.Library.Catalogue;
using Bnsit.ArqLibrarian.Library.Issues;
using Bnsit.ArqLibrarian.Library.Ratings;
using Bnsit.ArqLibrarian.Library.Users;

namespace Bnsit.ArqLibrarian
{
    static class MainClass
    {
        public static void Main(string[] args)
        {
            var application = new Application(new ConsoleIn(), new ConsoleOut());

            var booksRepository = CreateBooksRepository();
            CatalogueApplicationService catalogueApplicationService = new BaseCatalogueApplicationService(booksRepository);
            application.Setup(catalogueApplicationService);

            UserRepository userRepository = CreateMemoryUserRepository();
            UsersApplicationService usersApplicationService = new BaseUsersApplicationService(userRepository);

            application.Setup(new BaseIssuesApplicationService(
                usersApplicationService, catalogueApplicationService, CreateMemoryIssuesRepository(), new IssueFactory()));
            
            application.Setup(new BaseRatingApplicationService(
                CreateMemoryRatingRepository(), new RatingFactory(usersApplicationService), 
                catalogueApplicationService, usersApplicationService));

            application.Setup(usersApplicationService);

            application.Start();
        }

        private static RatingRepository CreateMemoryRatingRepository()
        {
            var repository = new MemoryRatingRepository();
            repository.Init();

            return repository;
        }

        private static IssueRepository CreateMemoryIssuesRepository()
        {
            var repository = new MemoryIssueRepository();
            repository.Init();
            
            return repository;
        }

        private static UserRepository CreateMemoryUserRepository()
        {
            var repository = new MemoryUserRepository();
            repository.Init();
            return repository;
        }

        private static BookRepository CreateBooksRepository()
        {
            var repository = new MemoryBookRepository();
            repository.Init();
            
            return repository;
        }
    }
}
