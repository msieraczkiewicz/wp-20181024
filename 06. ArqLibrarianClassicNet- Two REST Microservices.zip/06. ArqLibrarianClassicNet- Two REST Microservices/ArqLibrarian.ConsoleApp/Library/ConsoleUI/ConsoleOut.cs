﻿using System;
namespace Bnsit.ArqLibrarian.Library.ConsoleUI
{
    public class ConsoleOut : UserOut
    {
        public void Print(string text)
        {
            Console.Write(text);
        }

        public void PrintLine(string text)
        {
            Console.WriteLine(text);
        }
    }
}
