﻿
namespace Bnsit.ArqLibrarian.Library.ConsoleUI
{
    public interface UserIn
    {
        string ReadLine();
    }
}
