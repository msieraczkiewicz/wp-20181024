﻿using System.Collections.Generic;
using System.Linq;
using Bnsit.ArqLibrarian.Library.Utils;
using Bnsit.ArqLibrarian.Library.Catalogue;
using Bnsit.ArqLibrarian.Library.Issues;
using Bnsit.ArqLibrarian.Library.Ratings;
using Bnsit.ArqLibrarian.Library.Users;

namespace Bnsit.ArqLibrarian.Library.ConsoleUI
{
    public class Application
    {
        private CatalogueApplicationService catalogueService;
        private IssuesApplicationService issuesApplicationService;
        private RatingApplicationService ratingService;
        private UsersApplicationService usersService;

        //for now application works for the only sample user with id = 1
        //it will be more dynamic when login process will be supported
        long userId = 1L;
        private UserIn userIn;
        private UserOut userOut;

        public Application(UserIn userIn, UserOut userOut)
        {
            this.userIn = userIn;
            this.userOut = userOut;
        }

        public bool Start()
        {
            userOut.PrintLine("Welcome to the ArqLibrarian");

            var running = true;

            while (running) {
                userOut.Print("> ");
                var commandString = userIn.ReadLine();
                var args = commandString.Split(' ');
                var commandName = args[0];

                switch (commandName)
                {
                    case "exit":
                        running = false;
                        break;
                    case "search":
                        SearchBook(commandString);
                        break;
                    case "rate":
                        RateBook(args);
                        break;
                    case "rating":
                        ShowRatingDetails(args);
                        break;
                    case "add":
                        AddBook();
                        break;
                    case "issue":
                        IssueBook(args);
                        break;
                    case "return":
                        ReturnBook(args);
                        break;
                    case "status":
                        ShowStatus(args);
                        break;
                    default:
                        userOut.PrintLine($"Comand {commandName} not recognized");
                        break;
                }
            }

            return running;
        }

        private void ReturnBook(string[] args)
        {
            if (Is.NotValidLength(args, 2, "Wrong return command format. Try: return [book id]")
                || Is.NotNumber(args[1], "Wrong return command format. Book id should be a number."))
            {
                return;
            }

            var bookId = long.Parse(args[1]);
            if (!issuesApplicationService.Issued(bookId))
            {
                userOut.PrintLine($"Book with id = {bookId} is not issued.");
                return;
            }

            issuesApplicationService.Return(bookId);

            var book = catalogueService.FindById(bookId);
            userOut.PrintLine($"Book successfully returned");

            Print(book);
        }

        private void ShowRatingDetails(string[] args)
        {
            if (Is.NotValidLength(args, 2, "Wrong status command format. Try: rating [book id]")
                || Is.NotNumber(args[1], "Wrong status command format. Book id should be a number."))
            {
                return;
            }

            var bookId = long.Parse(args[1]);
            if (!catalogueService.Exists(bookId))
            {
                userOut.PrintLine($"Book with id = {bookId} doesn't exist.");
                return;
            }

            var book = catalogueService.FindById(bookId);
            Print(book);

            RatingDetails details = ratingService.Details(bookId);
            foreach (RatingItem item in details.Ratings)
            {
                userOut.PrintLine($"{item.Nickname} - {item.Value} [{item.When}]");
            }
        }

        private void ShowStatus(string[] args)
        {
            if (Is.NotValidLength(args, 2, "Wrong status command format. Try: status [book id]")
                || Is.NotNumber(args[1], "Wrong status command format. Book id should be a number."))
            {
                return;
            }

            var bookId = long.Parse(args[1]);
            if (!catalogueService.Exists(bookId)) {
                userOut.PrintLine($"Book with id = {bookId} doesn't exist.");
                return;
            }

            bool borrowed = issuesApplicationService.Issued(bookId);
            var book = catalogueService.FindById(bookId);
            userOut.PrintLine($"{BorrowedToString(borrowed)} {BasicInfoFor(book)}");

        }

        private void IssueBook(string[] args)
        {
            string [] validTermsTypes = { "normal", "long", "short" };

            if (Is.NotValidLength(args, 4, "Wrong issue command format. Try: issue [book id] [user id] [type]")
                || Is.NotNumber(args[1], "Wrong issue command format. Book id should be a number.")
                || Is.NotNumber(args[2], "Wrong issue command format. User id should be a number.")
                || Is.StringNotIn(args[3], validTermsTypes, "Type should be one of [short, normal, long]"))
            {
                return;
            }

            var bookId = long.Parse(args[1]);
            if (!catalogueService.Exists(bookId))
            {
                userOut.PrintLine($"Book with id = {bookId} doesn't exist.");
                return;
            }

            var issuingUserId = long.Parse(args[2]);
            if (!usersService.Exists(issuingUserId)) {
                userOut.PrintLine($"User with id = {issuingUserId} doesn't exist.");
                return;                
            }

            if (issuesApplicationService.Issued(bookId)) 
            {
                userOut.PrintLine($"Book with id = {bookId} already issued.");
                return;                   
            }

            var type = args[3];
            issuesApplicationService.Issue(issuingUserId, bookId, type);

            var book = catalogueService.FindById(bookId);
            userOut.PrintLine($"Borrowed: {BasicInfoFor(book)}");
        }

        private void RateBook(string[] args)
        {
            if (Is.NotValidLength(args, 3, "Wrong rate command format. Try: rate [book id] [rating]")
                || Is.NotNumber(args[1], "Wrong rate command format. Book id should be a number") 
                || Is.NotNumber(args[2], "Wrong rate command format. Rating should be a number")
                || Is.NumberNotBetween(args[2], 1, 5, "Rating should be a number between 1 and 5."))
            {
                return;
            }

            var bookId = long.Parse(args[1]);
            if (!catalogueService.Exists(bookId))
            {
                userOut.PrintLine($"Book with id = {bookId} doesn't exist.");
                return;
            }

            var rating = int.Parse(args[2]);
            this.ratingService.Rate(bookId, userId, rating);

            var totalRating = this.ratingService.Rating(bookId);
            var book = catalogueService.FindById(bookId);           
            userOut.PrintLine($"{book.Title} rated: {rating}, total rating: {totalRating}");
        }

        private void SearchBook(string command)
        {  
            IEnumerable<BookDto> books = null;
            if (HasParameters(command))
            {
                books = catalogueService.FindAll();
            }
            else
            {
                var toSearch = SubstringAfterFirstSpace(command);
  
                books = catalogueService.FindByTitle(toSearch);
                userOut.PrintLine(books.Any() ? $"Found: '{toSearch}'" : $"'{toSearch}' title not Found");
            }

            Print(books);
        }

        private static bool HasParameters(string command)
        {
            return command.IndexOf(' ') < 0;
        }

        private static string SubstringAfterFirstSpace(string command)
        {
            return command.Substring(command.IndexOf(' ') + 1);
        }

        private void Print(IEnumerable<BookDto> books)
        {
            foreach (var book in books)
            {
                Print(book);
            }
        }

        private void Print(BookDto book)
        {
            userOut.PrintLine($"{book.Id}: {BasicInfoFor(book)}, rating: {book.Rating}");
        }

        private string BorrowedToString(bool borrowed)
        {
            return borrowed ? "[borrowed]" : "[available]";
        }

        private string BasicInfoFor(BookDto book)
        {
            return $"\"{book.Title}\" - {book.Author}, {book.Category}";
        }

        private void AddBook()
        {
            userOut.PrintLine("Adding a new book");
            userOut.Print("Title: ");
            var title = userIn.ReadLine();
            
            userOut.Print("Author: ");
            var author = userIn.ReadLine();

            userOut.Print("isbn: ");
            var isbn = userIn.ReadLine();
            
            userOut.Print("Publihser: ");
            var publisher = userIn.ReadLine();
            
            userOut.Print("Year: ");
            var yearString = userIn.ReadLine();
            var year = int.Parse(yearString);
            
            userOut.Print("Category: ");
            var category = userIn.ReadLine();

            catalogueService.AddBook(title, author, isbn, publisher, year, category);
        }

        public void Setup(CatalogueApplicationService service)
        {
            this.catalogueService = service;
        }

        public void Setup(IssuesApplicationService issuesApplicationService)
        {
            this.issuesApplicationService = issuesApplicationService;
        }

        public void Setup(RatingApplicationService service) 
        {
            this.ratingService = service;
        }

        public void Setup(UsersApplicationService usersApplicationService)
        {
            this.usersService = usersApplicationService;
        }
    }
}
