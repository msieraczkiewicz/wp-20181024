﻿
namespace Bnsit.ArqLibrarian.Library.ConsoleUI
{
    public interface UserOut
    {
        void Print(string text);

        void PrintLine(string text);
    }
}
