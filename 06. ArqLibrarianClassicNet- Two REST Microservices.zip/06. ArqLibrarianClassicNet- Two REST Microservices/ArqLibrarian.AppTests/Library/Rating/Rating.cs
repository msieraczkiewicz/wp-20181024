﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
namespace Bnsit.ArqLibrarian.Library.Rating
{
    [TestClass]
    public class Rating
    {
        private BaseFixture fixture = null;

        [TestInitialize]
        public void SetupFixture()
        {
            fixture = new BaseFixture();
        }
        [TestMethod]
        public void ShouldShowRating()
        {
            fixture.ApplicationStarted();
            fixture.HasBook("Ogniem i mieczem", "Henryk Sienkiewicz", "978-83-08-06015-5", "Wydawnictwo Literackie", 2016, "Podręczniki i lektury szkolne");

            long id = fixture.BookIdByTitle("Ogniem i mieczem");
            const int Rating = 4;

            //when
            fixture.UserEnters($"rate {id} {Rating}");
            fixture.UserEnters($"rating {id}");

            fixture.Then();
            fixture.SystemShows($"rating: {Rating}");
        }
    }
}
