﻿using System.Collections.Generic;
using Bnsit.ArqLibrarian.Library.ConsoleUI;

namespace Bnsit.ArqLibrarian.Library
{
    public class SpyUserIn : UserIn
    {
        private readonly InputAware input;
        private readonly Queue<string> entered = new Queue<string>();

        public SpyUserIn(InputAware input)
        {
            this.input = input;
        }

        internal void EnterLine(string text)
        {
            entered.Enqueue(text);
        }

        public string ReadLine()
        {
            string text = entered.Dequeue();
            input.OnTextLineEntered(text);
            return text;
        }
    }
}
