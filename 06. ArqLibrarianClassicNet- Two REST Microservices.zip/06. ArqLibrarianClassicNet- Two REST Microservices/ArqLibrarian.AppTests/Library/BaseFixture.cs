﻿using System.Linq;
using Bnsit.ArqLibrarian.Library.Catalogue;
using Bnsit.ArqLibrarian.Library.ConsoleUI;
using Bnsit.ArqLibrarian.Library.Issues;
using Bnsit.ArqLibrarian.Library.Ratings;
using Bnsit.ArqLibrarian.Library.Users;
using Bnsit.ArqLibrarian.Library.Utils;

namespace Bnsit.ArqLibrarian.Library
{
    public class BaseFixture
    {
        private Application application;
        private SpyUserIn userIn;
        private SpyUserOut userOut;

        private CatalogueApplicationService catalogueService;
        private IssuesApplicationService issuesService;
        private UsersApplicationService usersService;
        private RatingApplicationService ratingService;

        public static int StartBooksCount = 7; 

        public void ApplicationStarted()
        {
            this.userOut = new SpyUserOut();
            this.userIn = new SpyUserIn(userOut);

            this.application = new Application(userIn, userOut);

            BookRepository booksRepository = CreateBooksRepository();
            this.catalogueService = new BaseCatalogueApplicationService(booksRepository);
            application.Setup(catalogueService);

            UserRepository userRepository = CreateMemoryUserRepository();
            this.usersService = new BaseUsersApplicationService(userRepository);
            application.Setup(usersService);

            IssueRepository issuesRepository = CreateMemoryIssuesRepository();
            this.issuesService = new BaseIssuesApplicationService(
                usersService, catalogueService, issuesRepository, new IssueFactory());
            application.Setup(issuesService);

            RatingRepository ratingRepository = CreateMemoryRatingRepository();
            this.ratingService = new BaseRatingApplicationService(
                ratingRepository, new RatingFactory(usersService), catalogueService, usersService);
            application.Setup(ratingService);
        }

        public void HasBook(string title, string author, string isbn, string publisher, int year, string category)
        {
            this.catalogueService.AddBook(title, author, isbn, publisher, year, category);
        }

        public void UserEnters(string text)
        {
            this.userIn.EnterLine(text);
        }

        public void Then()
        {
            this.userIn.EnterLine("exit");
            this.application.Start();
        }

        public void SystemShows(string text)
        {   
            // converting from more friedly regexp
            this.userOut.AssertContains(text.Replace("*", ".*").Replace("[", "\\[").Replace("]", "\\]"));
        }

        public void SystemShowsAtLeastLines(int expectedCount)
        {
            this.userOut.AssertCountainsAtLeastLines(expectedCount);
        }

        public long BookIdByTitle(string title)
        {
            return this.catalogueService.FindByTitle(title).FirstOrDefault().Id;
        }

        public static string Title(string title)
        {
            return title;
        }

        public static string Author(string author)
        {
            return author;
        }

        public static string Publisher(string publisher)
        {
            return publisher;
        }

        private static RatingRepository CreateMemoryRatingRepository()
        {
            var repository = new MemoryRatingRepository();
            repository.Init();

            return repository;
        }

        private static IssueRepository CreateMemoryIssuesRepository()
        {
            var repository = new MemoryIssueRepository();
            Generated.ResetIssueId();
            repository.Init();

            return repository;
        }

        private static UserRepository CreateMemoryUserRepository()
        {
            var repository = new MemoryUserRepository();
            Generated.ResetUserId();
            repository.Init();
            return repository;
        }

        private static BookRepository CreateBooksRepository()
        {
            var repository = new MemoryBookRepository();
            Generated.ResetBookId();
            repository.Init();

            return repository;
        }
    }
}
