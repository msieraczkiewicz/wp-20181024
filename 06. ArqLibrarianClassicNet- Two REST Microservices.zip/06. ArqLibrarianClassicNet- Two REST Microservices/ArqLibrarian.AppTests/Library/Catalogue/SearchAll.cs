﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    [TestClass]
    public class SearchAll
    {
        private BaseFixture fixture = null;

        [TestInitialize]
        public void SetupFixture()
        {
            fixture = new BaseFixture();
        }

        [TestMethod]
        public void ShouldSearchAllBooks()
        {
            fixture.ApplicationStarted();

            fixture.UserEnters("search");

            fixture.Then();
            fixture.SystemShows(BaseFixture.Title("Karolcia"));
            fixture.SystemShows(BaseFixture.Author("Maria Kruger"));
            fixture.SystemShows(BaseFixture.Title("Renesans"));
            fixture.SystemShows(BaseFixture.Author("Jerzy Konieczny"));
            fixture.SystemShowsAtLeastLines(BaseFixture.StartBooksCount);
        }
    }
}
