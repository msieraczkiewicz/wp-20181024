﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    [TestClass]
    public class SearchByTitle
    {
        private BaseFixture fixture = null;

        [TestInitialize]
        public void SetupFixture()
        {
            fixture = new BaseFixture();
        }

        [TestMethod]
        public void ShouldSearchByTitle()
        {
            fixture.ApplicationStarted();

            fixture.HasBook("Ogniem i mieczem", "Henryk Sienkiewicz", "978-83-08-06015-5", "Wydawnictwo Literackie", 2016, "Podręczniki i lektury szkolne");

            //when
            fixture.UserEnters("search Ogniem i mieczem");

            fixture.Then();
            fixture.SystemShows("Found: 'Ogniem i mieczem'");
            fixture.SystemShows(BaseFixture.Title("Ogniem i mieczem"));
        }
    }
}
