﻿
namespace Bnsit.ArqLibrarian.Library
{
    public interface InputAware
    {
        void OnTextLineEntered(string text);
    }
}
