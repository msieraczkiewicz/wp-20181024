﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Bnsit.ArqLibrarian.Library.Issues
{
    [TestClass]
    public class ReturnABook
    {
        private BaseFixture fixture = null;

        [TestInitialize]
        public void SetupFixture()
        {
            fixture = new BaseFixture();
        }

        [TestMethod]
        public void ShouldReturnABook()
        {
            fixture.ApplicationStarted();

            fixture.HasBook("Ogniem i mieczem", "Henryk Sienkiewicz", "978-83-08-06015-5", "Wydawnictwo Literackie", 2016, "Podręczniki i lektury szkolne");
            var id = fixture.BookIdByTitle("Ogniem i mieczem");
            var userId = 1;
            var issueType = "normal";

            //when

            fixture.UserEnters($"issue {id} {userId} {issueType}");
            fixture.UserEnters($"return {id}");
            fixture.UserEnters($"status {id}");

            fixture.Then();
            fixture.SystemShows("[available]*Ogniem i mieczem*");
        }
    }
}
