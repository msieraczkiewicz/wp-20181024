﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Bnsit.ArqLibrarian.Library.Startup
{
    [TestClass]
    public class ApplicationStartup
    {
        private BaseFixture fixture;

        [TestInitialize]
        public void SetupFixture()
        {
            this.fixture = new BaseFixture();
        }


        [TestMethod]
        public void ShouldShowHelloAtTheBegining()
        {
            fixture.ApplicationStarted();

            fixture.Then();
            fixture.SystemShows("Welcome to the ArqLibrarian");
        }
    }
}
