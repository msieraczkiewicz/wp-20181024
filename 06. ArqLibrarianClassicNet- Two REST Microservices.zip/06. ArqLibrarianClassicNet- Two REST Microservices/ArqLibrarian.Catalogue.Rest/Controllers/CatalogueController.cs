﻿using Microsoft.AspNetCore.Mvc;
using Bnsit.ArqLibrarian.Library.Catalogue;

namespace ArqLibrarian.Catalogue.Rest.Controllers
{
    [Route("api/[controller]/books")]
    public class CatalogueController : Controller
    {
        private CatalogueApplicationService catalogue;

        public CatalogueController(CatalogueApplicationService catalogue)
        {
            this.catalogue = catalogue;
        }

        [HttpGet]
        public IActionResult Find([FromQuery]string title = "")
        {
            if (title == null || title.Equals(""))
            {
                return Ok(this.catalogue.FindAll());
            }

            return Ok(this.catalogue.FindByTitle(title));
        }

        [HttpGet]
        [Route("{id:long}")]
        public IActionResult FindById(long id)
        {
            try 
            {
                return Ok(this.catalogue.FindById(id));
            }
            catch (BookNotFoundException e)
            {
                return NotFound(e.Message);
            }
        }

        [HttpGet]
        [Route("{id:long}/description")]
        public IActionResult FindByDescription(long id)
        {
            try
            {
                return Ok(this.catalogue.FindDescription(id));
            }
            catch (BookNotFoundException e)
            {
                return NotFound(e.Message);
            }
        }

        [HttpGet]
        [Route("{id:int}/exists")]
        public IActionResult Exists(long id)
        {
            return Ok(this.catalogue.Exists(id));
        }

        [HttpPost]
        public IActionResult AddBook([FromBody]Book book)
        {
            this.catalogue.AddBook(book.Title, book.Author, book.Isbn, book.Publisher, book.Year, book.Category);
            return Ok($"Added book: " + book.ToString());
        }

        [Route("rating-changed")]
        [HttpPut]
        public IActionResult RatingChanged([FromBody]RatingChangedEvent ratingChangedEvent)
        {
            this.catalogue.RatingChanged(ratingChangedEvent);
            return Ok($"Rating changed for book id = {ratingChangedEvent.BookId} to {ratingChangedEvent.Rating}");
        }
    }
}