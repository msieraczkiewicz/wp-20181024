﻿using System.Collections.Generic;

namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    public class BookDto
    {
        public long Id { get; set; }
        public string Title { get; set;}
        public string Author { get; set; }
        public string Isbn { get; set; }
        public string Publisher { get; set; }
        public int Year { get; set; }
        public string Category { get; set; }
        public double Rating { get; set; }


        public override string ToString()
        {
            return $"{this.Id}: '{this.Title}' - {this.Author} [{this.Isbn}] '{this.Publisher}', {this.Year}, '{this.Category}'" +
                $" {Rating}";
        }

    }
}