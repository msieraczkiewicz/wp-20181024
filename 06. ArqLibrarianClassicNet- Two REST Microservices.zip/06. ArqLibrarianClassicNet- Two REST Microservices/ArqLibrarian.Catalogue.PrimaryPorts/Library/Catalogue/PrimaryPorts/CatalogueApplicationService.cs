﻿using System.Collections.Generic;

namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    public interface CatalogueApplicationService
    {
        IEnumerable<BookDto> FindAll();

        void AddBook(string title, string author, string isbn, string publisher, int year, string category);

        IEnumerable<BookDto> FindByTitle(string title);

        bool Exists(long bookId);

        string FindDescription(long bookId);

        BookDto FindById(long id);

        void RatingChanged(RatingChangedEvent ratingChangedEvent);

    }
}