﻿namespace Bnsit.ArqLibrarian.Library.Catalogue
{
    public class RatingChangedEvent
    {
        public long BookId { get; }
        public double Rating { get; }

        public RatingChangedEvent(long BookId, double Rating)
        {
            this.BookId = BookId;
            this.Rating = Rating;
        }
    }
}