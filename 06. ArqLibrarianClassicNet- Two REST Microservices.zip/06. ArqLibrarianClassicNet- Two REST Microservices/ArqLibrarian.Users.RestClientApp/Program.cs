﻿using System;
using ArqLibrarian.Users.RestClient;
using ArqLibrarian.UtilsCore.Rest;

namespace ArqLibrarian.Users.RestClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting client...");
            UsersClient users = new UsersClient(new RestJsonClient("http://localhost:5000"));
            Console.WriteLine("Client started...");

            for (int i = 1; i <= 10; i++)
            {
                try
                {
                    var nickname = users.FindNickname(i).Result;
                    Console.WriteLine(i + ". " + nickname);

                    var description = users.FindDescription(i).Result;
                    Console.WriteLine(i + ". " + description);

                    var exists = users.Exists(i).Result;
                    Console.WriteLine(i + ". " + exists);

                }
                catch (Exception e) 
                {
                    Console.WriteLine(i + ". " + e.InnerException.Message);
                }
            }

            Console.WriteLine("Press Return when ready");
            Console.ReadLine();
        }
    }
}
