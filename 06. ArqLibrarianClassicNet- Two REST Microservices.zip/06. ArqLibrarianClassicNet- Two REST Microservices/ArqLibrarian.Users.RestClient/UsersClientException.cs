﻿using System;
using System.Runtime.Serialization;

namespace ArqLibrarian.Users.RestClient
{
    [Serializable]
    public class UsersClientException : Exception
    {
        public UsersClientException()
        {
        }

        public UsersClientException(string message) : base(message)
        {
        }

        public UsersClientException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected UsersClientException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}