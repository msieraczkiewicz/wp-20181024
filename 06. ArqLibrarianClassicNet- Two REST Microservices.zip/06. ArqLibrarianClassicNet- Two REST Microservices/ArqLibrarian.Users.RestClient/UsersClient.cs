﻿using System.Threading.Tasks;
using ArqLibrarian.UtilsCore.Rest;

namespace ArqLibrarian.Users.RestClient
{
    public class UsersClient
    {
        private RestJsonClient http;

        public UsersClient(RestJsonClient http) 
        {
            this.http = http;
        }

        public async Task<string> FindNickname(long userId)
        {
            return await http.GetAsync<string, UsersClientException>($"/api/users/{userId}/nickname");
        }

        public async Task<string> FindDescription(long userId)
        {
            return await http.GetAsync<string, UsersClientException>($"/api/users/{userId}/description");
        }

        public async Task<bool> Exists(long userId)
        {
            return await http.GetAsync<bool, UsersClientException>($"/api/users/{userId}/exists");
        }

    }
}
