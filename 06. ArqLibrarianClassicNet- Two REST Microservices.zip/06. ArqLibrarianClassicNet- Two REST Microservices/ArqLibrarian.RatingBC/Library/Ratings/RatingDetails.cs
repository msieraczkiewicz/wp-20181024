﻿using System.Collections.Generic;

namespace Bnsit.ArqLibrarian.Library.Ratings
{
    // DTO
    public class RatingDetails
    {
        public double Value { get; internal set; }
        public List<RatingItem> Ratings = new List<RatingItem>();

        internal void Add(RatingItem ratingItem)
        {
            Ratings.Add(ratingItem);
        }
    }
}