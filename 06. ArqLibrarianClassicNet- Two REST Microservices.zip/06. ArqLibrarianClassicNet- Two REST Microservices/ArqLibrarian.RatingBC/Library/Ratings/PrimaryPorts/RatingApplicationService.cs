﻿namespace Bnsit.ArqLibrarian.Library.Ratings
{
    public interface RatingApplicationService
    {
        void Rate(long bookId, long userId, int value);

        RatingDetails Details(long bookId);

        double Rating(long bookId);
    }
}
