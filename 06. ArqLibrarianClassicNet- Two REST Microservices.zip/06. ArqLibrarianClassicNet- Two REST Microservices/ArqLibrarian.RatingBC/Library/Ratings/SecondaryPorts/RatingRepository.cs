﻿namespace Bnsit.ArqLibrarian.Library.Ratings
{
    public interface RatingRepository
    {
        Rating FindBy(long bookId);

        void Add(Rating rating);

        void Update(Rating rating);
    }
}