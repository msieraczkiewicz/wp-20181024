﻿using System.Collections.Generic;
using System.Linq;

namespace Bnsit.ArqLibrarian.Library.Ratings
{
    public class MemoryRatingRepository : RatingRepository
    {
        static private List<Rating> ratings = new List<Rating>();
        
        public Rating FindBy(long bookId)
        {
            return ratings.FirstOrDefault(r => r.BookId == bookId);
        }

        public void Add(Rating rating)
        {
            ratings.Add(rating);
        }

        public void Update(Rating rating)
        {
            // inmemory implementation - nothing to be done
        }

        public void Init()
        {
            Clear();
            Rating rating1 = new Rating(1);
            rating1.Rate(1,"kowalski", value: 4);
            rating1.Rate(2, "nowak", value: 2);
            ratings.Add(rating1);

            Rating rating2 = new Rating(2);
            rating2.Rate(2, "nowak", value: 1);
            rating2.Rate(3, "koper", value: 4);
            ratings.Add(rating2);

            Rating rating3 = new Rating(3);
            rating3.Rate(1, "kowalski", value: 1);
            rating3.Rate(3, "koper", value: 5);
            ratings.Add(rating3);

            Rating rating4 = new Rating(4);
            rating4.Rate(1,"kowalski", value: 2);
            rating4.Rate(2, "nowak", value: 2);
            ratings.Add(rating4);
        }

        public void Clear()
        {
            ratings.Clear();
        }
    }
}