﻿using System;
using System.Runtime.Serialization;

namespace Bnsit.ArqLibrarian.Library.Ratings
{
    [Serializable]
    internal class RatingNotFoundException : RatingException
    {
        public RatingNotFoundException()
        {
        }

        public RatingNotFoundException(string message) : base(message)
        {
        }

        public RatingNotFoundException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected RatingNotFoundException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}