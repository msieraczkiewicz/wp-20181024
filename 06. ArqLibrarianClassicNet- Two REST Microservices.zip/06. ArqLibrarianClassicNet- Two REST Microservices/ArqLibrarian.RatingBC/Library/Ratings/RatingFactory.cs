﻿using Bnsit.ArqLibrarian.Library.Users;

namespace Bnsit.ArqLibrarian.Library.Ratings
{
    public class RatingFactory
    {
        private UsersApplicationService usersApplicationService;

        public RatingFactory(UsersApplicationService usersApplicationService)
        {
            this.usersApplicationService = usersApplicationService;
        }
        
        public Rating Create(long bookId)
        {
            return new Rating(bookId);
        }
    }
}