﻿using ArqLibrarianClassic.Library;

namespace ArqLibrarianClassic
{
    static class MainClass
    {
        public static void Main(string[] args)
        {
            var application = new Application();
            var booksDao = CreateBooksDao();
            application.Setup(new BooksManager(booksDao));
            application.Setup(new BorrowingManager(CreateMemoryUserDao(), booksDao, CreateMemoryBorrowingDao()));
            application.Start();
        }

        private static BorrowingDao CreateMemoryBorrowingDao()
        {
            var dao = new BorrowingDao();
            dao.Init();
            
            return dao;
        }

        private static UserDao CreateMemoryUserDao()
        {
            var dao = new UserDao();
            dao.Init();
            return dao;
        }

        private static BooksDao CreateBooksDao()
        {
            var dao = new BooksDao();
            dao.Init();
            
            return dao;
        }
    }
}
