﻿using System;
using System.Collections.Generic;
using System.Linq;
using ArqLibrarianClassic.Library;

namespace ArqLibrarianClassic
{
    public class Application
    {
        private BooksManager booksManager;
        private BorrowingManager borrowingManager;

        //for now application works for the only sample user with id = 1
        //it will be more dynamic when login process will be supported
        long userId = 1L;

        public bool Start()
        {
            Console.WriteLine("Welcome to the ArqLibrarian");

            var running = true;

            while (running) {
                Console.Write("> ");
                var commandString = Console.ReadLine();
                var args = commandString.Split(' ');
                var commandName = args[0];

                switch (commandName)
                {
                    case "exit":
                        running = false;
                        break;
                    case "search":
                        SearchBook(commandString);
                        break;
                    case "rate":
                        RateBook(args);
                        break;
                    case "add":
                        AddBook();
                        break;
                    case "borrow":
                        BorrowBook(args);
                        break;
                    case "status":
                        ShowStatus(args);
                        break;
                    default:
                        Console.WriteLine($"Comand {commandName} not recognized");
                        break;
                }
            }

            return running;
        }

        private void ShowStatus(string[] args)
        {
            if (Is.NotValidLength(args, 2, "Wrong status command format. Try: status [book id]")
                || Is.NotNumber(args[1], "Wrong status command format. Book id should be a number."))
            {
                return;
            }

            var bookId = long.Parse(args[1]);
            if (!booksManager.Exists(bookId)) {
                Console.WriteLine($"Book with id = {bookId} doesn't exist.");
                return;
            }

            bool borrowed = borrowingManager.Borrowed(bookId);
            var book = booksManager.FindById(bookId);
            Console.WriteLine($"{BorrowedToString(borrowed)} {BasicInfoFor(book)}");

        }

        private void BorrowBook(string[] args)
        {
            if (Is.NotValidLength(args, 2, "Wrong borrow command format. Try: borrow [book id]")
                || Is.NotNumber(args[1], "Wrong borrow command format. Book id should be a number."))
            {
                return;
            }

            var bookId = long.Parse(args[1]);
            if (!booksManager.Exists(bookId))
            {
                Console.WriteLine($"Book with id = {bookId} doesn't exist.");
                return;
            }

            var book = booksManager.FindById(bookId);
            borrowingManager.Borrow(userId, bookId);

            Console.WriteLine($"Borrowed: {BasicInfoFor(book)}");
        }

        private void RateBook(string[] args)
        {
            if (Is.NotValidLength(args, 3, "Wrong rate command format. Try: rate [book id] [rating]")
                || Is.NotNumber(args[1], "Wrong rate command format. Book id should be a number") 
                || Is.NotNumber(args[2], "Wrong rate command format. Rating should be a number")
                || Is.NumberNotBetween(args[2], 1, 5, "Rating should be a number between 1 and 5."))
            {
                return;
            }

            var bookId = long.Parse(args[1]);
            if (!booksManager.Exists(bookId))
            {
                Console.WriteLine($"Book with id = {bookId} doesn't exist.");
                return;
            }

            var rating = int.Parse(args[2]);
            var book = booksManager.FindById(bookId);
            booksManager.Rate(bookId, rating);
            var totalRating = booksManager.ComputeRatingFor(bookId);
            
            Console.WriteLine($"{book.Title} rated: {rating}, total rating: {totalRating}");
        }

        private void SearchBook(string command)
        {  
            IEnumerable<Book> books = null;
            if (HasParameters(command))
            {
                books = booksManager.FindAll();
            }
            else
            {
                var toSearch = SubstringAfterFirstSpace(command);
  
                books = booksManager.FindByTitle(toSearch);
                Console.WriteLine(books.Any() ? $"Found: '{toSearch}'" : $"'{toSearch}' title not Found");
            }

            Print(books);
        }

        private static bool HasParameters(string command)
        {
            return command.IndexOf(' ') < 0;
        }

        private static string SubstringAfterFirstSpace(string command)
        {
            return command.Substring(command.IndexOf(' ') + 1);
        }

        private void Print(IEnumerable<Book> books)
        {
            foreach (var book in books)
            {
                var rating = booksManager.ComputeRatingFor(book.Id);
                string ratingString = (Maths.ComapareWithPrecision(rating, -1.0, 0.0001) ? "not rated" : "" + rating);
                Console.WriteLine($"{book.Id}: {BasicInfoFor(book)}, rating: {ratingString}");
            }
        }

        private string BorrowedToString(bool borrowed)
        {
            return borrowed ? "[borrowed]" : "[available]";
        }

        private string BasicInfoFor(Book book)
        {
            return $"\"{book.Title}\" - {book.Author}, {book.Category}";
        }

        private void AddBook()
        {
            Console.WriteLine("Adding a new book");
            Console.Write("Title: ");
            var title = Console.ReadLine();
            
            Console.Write("Author: ");
            var author = Console.ReadLine();

            Console.Write("isbn: ");
            var isbn = Console.ReadLine();
            
            Console.Write("Publihser: ");
            var publisher = Console.ReadLine();
            
            Console.Write("Year: ");
            var yearString = Console.ReadLine();
            var year = int.Parse(yearString);
            
            Console.Write("Category: ");
            var category = Console.ReadLine();

            booksManager.Create(title, author, isbn, publisher, year, category);
        }

        public void Setup(BooksManager manager)
        {
            this.booksManager = manager;
        }

        public void Setup(BorrowingManager manager)
        {
            this.borrowingManager = manager;
        }
    }
}
