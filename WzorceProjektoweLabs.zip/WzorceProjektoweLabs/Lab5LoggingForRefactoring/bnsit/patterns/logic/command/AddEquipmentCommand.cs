﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lab5ForRefactoring.bnsit.patterns.model;
using Lab5ForRefactoring.bnsit.patterns.logic;

namespace Lab5ForRefactoring.bnsit.patterns.logic.command
{
    public class AddEquipmentCommand : Command
    {
        public string Name
        {
            get { return "add_equipment"; } 
        }

        private ApplicationModel model = null;

        private EquipmentFactory equipmentFactory = new EquipmentFactory();

        public AddEquipmentCommand(ApplicationModel model)
        {
            this.model = model;
        }

        public void Execute(string param)
        {
            if (param == null || param.Equals(""))
            {
                Console.WriteLine("Missing equipment type parameter.");
                return;
            }

            Console.Write("Signature: ");
            String signature = Console.ReadLine();

            Console.Write("Cost: ");
            int cost = int.Parse(Console.ReadLine());

            Console.Write("Purchase Date (YYYY-MM-DD): ");
            DateTime purchaseDate = DateTime.Parse(Console.ReadLine());

            Equipment equipment = equipmentFactory.CreateEquipment(param, signature, cost, purchaseDate);

            Console.WriteLine("Which building (" + model.FindBuildingsNames() + ")?");
            String buildingName = Console.ReadLine();
            Building building = model.FindBuilding(buildingName);

            Console.WriteLine("Which elevation (" + model.FindElevationsNumbers(buildingName) + ")?");
            int elevationNo = int.Parse(Console.ReadLine());
            Elevation elevation = model.FindElevation(buildingName, elevationNo);


            Console.WriteLine("Which room (" + model.FindRoomsNumbers(buildingName, elevationNo) + ")?");
            int roomNumber = int.Parse(Console.ReadLine());
            Room room = model.FindRoom(buildingName, elevationNo, roomNumber);

            room.AddEquipment(equipment);
        }

        public void PrintHelp()
        {
            Console.WriteLine("Adds equipment (params: type={chair, table, painting, lamp, couch, plant})");
        }
    }
}