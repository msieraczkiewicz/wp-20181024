﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab5ForRefactoring.bnsit.patterns.model
{
    public class Plant : Equipment
    {
        public Plant() : base() { }

        public Plant(string signature, int cost, DateTime purchaseDate) : base(signature, cost, purchaseDate) { }
    }
}
