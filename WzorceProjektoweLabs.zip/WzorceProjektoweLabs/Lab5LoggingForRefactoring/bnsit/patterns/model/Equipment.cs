﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Lab5ForRefactoring.bnsit.patterns.model
{
    public abstract class Equipment
    {
        [XmlAttribute]
        public string Signature { get; set; }

        [XmlAttribute]
        public int Cost { get; set; }

        [XmlAttribute]
        public DateTime PurchaseDate { get; set; }

        public Equipment() { }

        public Equipment( string signature, int cost, DateTime purchaseDate )
        {
            this.Signature = signature;
            this.Cost = cost;
            this.PurchaseDate = purchaseDate;
        }
    }
}
