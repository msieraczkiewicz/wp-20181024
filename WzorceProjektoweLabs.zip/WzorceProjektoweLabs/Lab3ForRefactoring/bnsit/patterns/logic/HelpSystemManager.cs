﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab3ForRefactoring.bnsit.patterns.logic
{
    public class HelpSystemManager
    {
        public void PrintHelp(String command)
        {
            if (command.Equals("hello"))
            {
                PrintHelloHelp();
            }
            else if (command.Equals("add_building"))
            {
                PrintAddBuildingHelp();
            }
            else if (command.Equals("save"))
            {
                PrintSaveHelp();
            }
            else if (command.Equals("load"))
            {
                PrintLoadHelp();
            }
            else if (command.Equals("building_report"))
            {
                PrintBuildingReportHelp();
            }
            else if (command.Equals("exit"))
            {
                PrintExitHelp();
            }
            else if (command.Equals("help"))
            {
                PrintHelpHelp();
            }
        }

        public void PrintAllHelp()
        {
            PrintHelpHelp();
            PrintHelloHelp();
            PrintAddBuildingHelp();
            PrintSaveHelp();
            PrintLoadHelp();
            PrintBuildingReportHelp();
            PrintExitHelp();
        }

        private void PrintHelpHelp()
        {
            Console.WriteLine("Show commands help (params: [commandName])");
        }

        private void PrintExitHelp()
        {
            Console.WriteLine("Exits application");
        }

        private void PrintBuildingReportHelp()
        {
            Console.WriteLine("Prints buildings report. (params: reportType={dashed, indented, tree})");
        }

        private void PrintLoadHelp()
        {
            Console.WriteLine("Loads data from file (params: filename)");
        }

        private void PrintSaveHelp()
        {
            Console.WriteLine("Saves data to file (params: filename)");
        }

        private void PrintAddBuildingHelp()
        {
            Console.WriteLine("Starts building creator");
        }

        private void PrintHelloHelp()
        {
            Console.WriteLine("Prints hello message.");
        }
    }
}
