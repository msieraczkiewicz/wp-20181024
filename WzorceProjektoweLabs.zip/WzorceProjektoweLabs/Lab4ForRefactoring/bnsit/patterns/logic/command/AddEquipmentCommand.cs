﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lab4ForRefactoring.bnsit.patterns.model;

namespace Lab4ForRefactoring.bnsit.patterns.logic.command
{
    public class AddEquipmentCommand : Command
    {
        public string Name
        {
            get { return "add_equipment"; } 
        }

        private ApplicationModel model = null;

        public AddEquipmentCommand(ApplicationModel model)
        {
            this.model = model;
        }

        public void Execute(string param)
        {
            if (param == null || param.Equals(""))
            {
                Console.WriteLine("Missing equipment type parameter.");
                return;
            }

            Console.Write("Signature: ");
            String signature = Console.ReadLine();

            Console.Write("Cost: ");
            int cost = int.Parse(Console.ReadLine());

            Console.Write("Purchase Date (YYYY-MM-DD): ");
            DateTime purchaseDate = DateTime.Parse(Console.ReadLine());

            Equipment equipment = null;

            if (param.Equals("chair"))
            {
                equipment = new Chair(signature, cost, purchaseDate);
            }
            else if (param.Equals("table"))
            {
                equipment = new Table(signature, cost, purchaseDate);
            }
            else if (param.Equals("painting"))
            {
                equipment = new Painting(signature, cost, purchaseDate);
            }
            else if (param.Equals("lamp"))
            {
                equipment = new Lamp(signature, cost, purchaseDate);
            }
            else if (param.Equals("couch"))
            {
                equipment = new Couch(signature, cost, purchaseDate);
            }
            else if (param.Equals("plant"))
            {
                equipment = new Plant(signature, cost, purchaseDate);
            }

            Console.WriteLine("Which building (" + GetBuildingsNames() + ")?");
            String buildingName = Console.ReadLine();
            Building building = FindBuilding(buildingName);


            Console.WriteLine("Which elevation (" + GetElevationsNumbers(building) + ")?");
            int elevationNumber = int.Parse(Console.ReadLine());
            Elevation elevation = building.GetElevation(elevationNumber);


            Console.WriteLine("Which room (" + GetRoomsNumbers(elevation) + ")?");
            int roomNumber = int.Parse(Console.ReadLine());
            Room room = elevation.GetRoom(roomNumber);

            room.AddEquipment(equipment);

        }

        public void PrintHelp()
        {
            Console.WriteLine("Adds equipment...");
        }

        private string GetBuildingsNames()
        {
            string buildingsNames = "";

            foreach (var building in model.Buildings)
            {
                buildingsNames += building.Name + ", ";
            }

            return buildingsNames;
        }

        private Building FindBuilding(string name)
        {

            foreach (var building in model.Buildings)
            {
                if (building.Name.Equals(name))
                {
                    return building;
                }
            }
            return null;
        }

        private string GetElevationsNumbers(Building building)
        {
            string elevationsNumbers = "";

            foreach (Elevation elevation in building.Elevations)
            {
                elevationsNumbers += elevation.Number.ToString() + ", ";
            }

            return elevationsNumbers;

        }

        private string GetRoomsNumbers(Elevation elevation)
        {
            string roomsNumbers = "";

            foreach (Room room in elevation.Rooms)
            {
                roomsNumbers += room.Number.ToString() + ", ";
            }

            return roomsNumbers;
        }
    }
}
