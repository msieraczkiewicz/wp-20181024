﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Lab4ForRefactoring.bnsit.patterns.model
{
    public class Room
    {
        [XmlAttribute]
        public int Number { get; set; }

        [XmlArrayItem(typeof(Chair)), XmlArrayItem(typeof(Couch)),
        XmlArrayItem(typeof(Lamp)), XmlArrayItem(typeof(Painting)),
        XmlArrayItem(typeof(Plant)), XmlArrayItem(typeof(Table))]
        public List<Equipment> Equipments { get; set; }

        public Room() {
            Equipments = new List<Equipment>();
        }

        public Room(int number) : this()
        {
            this.Number = number;
        }

        public void AddEquipment(Equipment equipment)
        {
            Equipments.Add(equipment);
        }
    }
}
