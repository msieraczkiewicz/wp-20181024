﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab4ForRefactoring.bnsit.patterns.model
{
    public class Chair : Equipment
    {
        public Chair() : base() { }

        public Chair(string signature, int cost, DateTime purchaseDate) : base(signature, cost, purchaseDate) { }
    }
}
