﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab4ForRefactoring.bnsit.patterns.model
{
    public class Lamp : Equipment
    {
        public Lamp() : base() { }

        public Lamp(string signature, int cost, DateTime purchaseDate) : base(signature, cost, purchaseDate) { }
    }
}
