﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab6ForRefactoring.bnsit.patterns.logic.command.log
{
    public class LogExceptionCommandDecorator : CommandDecorator
    {

        public LogExceptionCommandDecorator(Command command) : base(command) { }

        public override void Execute(string param)
        {
            try
            {
                command.Execute(param);
            }
            catch (Exception e)
            {
                logger.LogDebug(e, "Command '" + Name + "' has thrown an exception");
                Console.WriteLine("Błąd krytyczny aplikacji. Więcej informacji w logach");
            }
        }
    }
}
