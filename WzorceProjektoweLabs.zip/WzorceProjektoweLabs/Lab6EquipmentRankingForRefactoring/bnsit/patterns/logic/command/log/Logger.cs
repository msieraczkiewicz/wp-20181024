﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Lab6ForRefactoring.bnsit.patterns.logic.command.log
{
    public class Logger
    {
        private const string LOGFILE = "application.log";
        private readonly bool append;

        private Type clazz;

        public Logger(Type clazz) : this(clazz, true) { }

        public Logger(Type clazz, bool append)
        {
            this.clazz = clazz;
            this.append = append;
        }

        public void LogDebug(string message)
        {
            PureLog(message);
        }

        public void LogDebug(Exception e, string message)
        {
            string trace = "";
            Exception ex = e;
            do {
                trace +=
                    "Exception: " + ex.GetType()
                    + "\nMessage: " + ex.Message
                    + "\nSource: " + ex.Source
                    + "\nStackTrace: " + ex.StackTrace
                    + "\nAnd next one...\n";
                ex = ex.InnerException;
            } while(ex != null);

            PureLog(message + ": " + trace);
        }

        protected void PureLog(string message)
        {
            FileMode mode = FileMode.Create;
            if (append)
            {
                mode = FileMode.Append;
            }

            StreamWriter writer = new StreamWriter(
                new FileStream(
                    LOGFILE, mode, 
                    FileAccess.Write, 
                    FileShare.None)
                );

            writer.WriteLine(DateTime.Now.ToString("dd/MM/yyyy HH:mm") + ": " + message);
            writer.Close();
        }
    }
}
