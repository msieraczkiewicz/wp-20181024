﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab6ForRefactoring.bnsit.patterns.logic.command.log
{
    public class LogInvocationCommandDecorator : CommandDecorator
    {
        public LogInvocationCommandDecorator(Command command) : base(command) { }

        public override void Execute(string param)
        {
            logger.LogDebug("Invoking command: '" + Name + "'");

            command.Execute(param);
        }
    }
}
