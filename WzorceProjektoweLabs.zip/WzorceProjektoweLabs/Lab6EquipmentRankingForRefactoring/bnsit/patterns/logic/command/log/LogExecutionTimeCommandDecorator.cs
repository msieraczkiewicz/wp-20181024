﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab6ForRefactoring.bnsit.patterns.logic.command.log
{
    public class LogExecutionTimeCommandDecorator : CommandDecorator
    {
        public LogExecutionTimeCommandDecorator(Command command) : base(command) {}

        public override void Execute(string param)
        {
            DateTime begin = DateTime.Now;

            command.Execute(param);

            DateTime end = DateTime.Now;

            logger.LogDebug("Time of execution of command '" + Name + "' = " + (end - begin) + "ms." );
        }
    }
}
