﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab6ForRefactoring.bnsit.patterns.logic.command.log
{
    public class LogExecutionCommandDecorator : CommandDecorator
    {
        public LogExecutionCommandDecorator(Command command) : base(command) { }

        public override void Execute(string param)
        {
            command.Execute(param);

            logger.LogDebug("Command '" + Name + "' has been executed");
        }
    }
}
