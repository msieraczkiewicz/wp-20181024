﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lab6ForRefactoring.bnsit.patterns.model;

namespace Lab6ForRefactoring.bnsit.patterns.logic.command
{
    public class EquipmentRankingCommand : Command
    {
        private EquipmentRanking equipmentRanking = new EquipmentRanking();

        private ApplicationModel model;

        public string Name
        {
            get { return "equipment_ranking"; }
        }

        public EquipmentRankingCommand(ApplicationModel model)
        {
            this.model = model;
        }

        public void Execute(string param)
        {
            		List<Equipment> ranking = new List<Equipment>();

		string rankingHeader = "";

		foreach ( Building building in model.Buildings ) {
			foreach ( Elevation elevation in building.Elevations ) {
				foreach ( Room room in elevation.Rooms ) {
					foreach ( Equipment equipment in room.Equipments ) {
						if ( param.Equals( "most_expensive" ) ) {
							rankingHeader = "Top Most Expensive Equipment Ranking:";
							equipmentRanking.doMostExpensiveRanking( equipment,
									ranking );
						} else if ( param.Equals( "oldest" ) ) {
							rankingHeader = "Top Oldest Equipment Ranking:";
							equipmentRanking.doOldestExpensiveRanking(
									equipment, ranking );
						} else if ( param.Equals( "plants" ) ) {
							rankingHeader = "All Plants Ranking:";
							equipmentRanking.doAllPlantsRanking( equipment,
									ranking );
						} else {
							Console.WriteLine( "Wrong parameter." );
							return;
						}
					}
				}
			}
		}

		Console.WriteLine( rankingHeader );
		
		foreach ( Equipment equipment in ranking ) {
			Console.WriteLine( "  Signature: " + equipment.Signature );
			Console.WriteLine( "  Cost: " + equipment.Cost );
            Console.WriteLine( "  Purchase Date: " + equipment.PurchaseDate.ToString("dd/MM/yyyy"));
		}
        }

        public void PrintHelp()
        {
            Console.WriteLine("It does equipment ranking. Usage equipment ranking <type>");
            Console.WriteLine("type := most_expensive | oldest | plants");
        }
    }
}
