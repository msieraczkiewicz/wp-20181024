﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lab6ForRefactoring.bnsit.patterns.model;

namespace Lab6ForRefactoring.bnsit.patterns.logic.command
{
    public class EquipmentRanking
    {
        public void doMostExpensiveRanking(Equipment equipment, List<Equipment> ranking)
        {
            ranking.Add(equipment);
            ranking.Sort(delegate(Equipment e1, Equipment e2)
            {
                return -1 * (e1.Cost - e2.Cost);
            });

            if (ranking.Count > 5)
            {
                ranking.RemoveRange(5, ranking.Count - 5);
            }
        }

        public void doOldestExpensiveRanking(Equipment equipment, List<Equipment> ranking)
        {
            ranking.Add(equipment);

            ranking.Sort(delegate(Equipment e1, Equipment e2)
            {
                return e1.PurchaseDate.CompareTo(e2.PurchaseDate);
            });

            if (ranking.Count > 5)
            {
                ranking.RemoveRange(5, ranking.Count - 5);
            }
        }

        public void doAllPlantsRanking(Equipment equipment, List<Equipment> ranking)
        {
            if (equipment is Plant)
            {
                ranking.Add(equipment);
            }
        }
    }
}
