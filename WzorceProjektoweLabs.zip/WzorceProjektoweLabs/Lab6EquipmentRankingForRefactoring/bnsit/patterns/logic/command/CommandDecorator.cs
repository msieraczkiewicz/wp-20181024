﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lab6ForRefactoring.bnsit.patterns.logic.command.log;

namespace Lab6ForRefactoring.bnsit.patterns.logic.command
{
    public abstract class CommandDecorator : Command
    {
        protected readonly Command command;
        protected readonly Logger logger = new Logger(typeof(Application));

        public string Name
        {
            get { return command.Name; }
        }

        public CommandDecorator(Command command)
        {
            this.command = command;
        }

        public abstract void Execute(string param);

        public void PrintHelp()
        {
            command.PrintHelp();
        }
    }
}
