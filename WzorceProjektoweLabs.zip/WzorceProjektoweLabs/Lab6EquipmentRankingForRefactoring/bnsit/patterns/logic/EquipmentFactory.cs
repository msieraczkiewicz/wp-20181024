﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lab6ForRefactoring.bnsit.patterns.model;

namespace Lab6ForRefactoring.bnsit.patterns.logic
{
    public class EquipmentFactory
    {
        public Equipment CreateEquipment(string type, string signature, int cost, DateTime purchaseDate)
        {
            if (type.Equals("chair"))
            {
                return new Chair(signature, cost, purchaseDate);
            }
            else if (type.Equals("table"))
            {
                return new Table(signature, cost, purchaseDate);
            }
            else if (type.Equals("painting"))
            {
                return new Painting(signature, cost, purchaseDate);
            }
            else if (type.Equals("lamp"))
            {
                return new Lamp(signature, cost, purchaseDate);
            }
            else if (type.Equals("couch"))
            {
                return new Couch(signature, cost, purchaseDate);
            }
            else if (type.Equals("plant"))
            {
                return new Plant(signature, cost, purchaseDate);
            }

            throw new ApplicationException( "There's no equipment type of :" + type );
        }
    }
}
