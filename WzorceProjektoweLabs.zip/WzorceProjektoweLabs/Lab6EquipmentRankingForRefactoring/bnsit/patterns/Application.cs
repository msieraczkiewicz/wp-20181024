﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lab6ForRefactoring.bnsit.patterns.model;
using Lab6ForRefactoring.bnsit.patterns.logic.report;
using Lab6ForRefactoring.bnsit.patterns.logic;
using Lab6ForRefactoring.bnsit.patterns.logic.command;
using Lab6ForRefactoring.bnsit.patterns.logic.command.log;


namespace Lab6ForRefactoring.bnsit.patterns
{
    public class Application
    {
        private readonly Logger logger = new Logger(typeof(Application));

        private const String PROMPT = "ees>";

        private ApplicationModel model = new ApplicationModel();

        private Dictionary<string, Command> commands = new Dictionary<string, Command>();

        private Boolean running = false;

        public void Init()
        {
            RegisterCommand(DecorateCommand(new HelloCommand()));
            RegisterCommand(DecorateCommand(new SaveCommand(model)));
            RegisterCommand(DecorateCommand(new LoadCommand(model)));
            RegisterCommand(DecorateCommand(new AddBuildingCommand(model)));
            RegisterCommand(DecorateCommand(new BuildingReportCommand(model)));
            RegisterCommand(DecorateCommand(new ExitCommand(this)));
            RegisterCommand(DecorateCommand(new HelpCommand(commands)));
            RegisterCommand(DecorateCommand(new AddEquipmentCommand(model)));
            RegisterCommand(DecorateCommand(new EquipmentRankingCommand(model)));
        }

        public void Stop()
        {
            running = false;
        }

        public void Start()
        {
            running = true;

            new HelloCommand().Execute(null);

            while (running)
            {
                Console.Write(PROMPT);
                string userCommand = Console.ReadLine();

                string[] commandAndParam = userCommand.Split(' ');
                string commandName = commandAndParam[0];

                bool unknownCommand = (!commands.ContainsKey(commandName));
                if (unknownCommand)
                {
                    Console.WriteLine("There's no command '" + commandName + "'");
                    continue;
                }

                bool hasParam = (commandAndParam.Length > 1);
                string param = null;
                if (hasParam)
                {
                    param = commandAndParam[1];
                }

                commands[commandName].Execute(param);
            }
        }

        private Command DecorateCommand(Command command)
        {
            return new LogInvocationCommandDecorator(
                new LogExecutionCommandDecorator(
                    new LogExecutionTimeCommandDecorator(
                        new LogExceptionCommandDecorator(
                        command))));
        }

        private void RegisterCommand(Command command)
        {
            commands.Add(command.Name, command);
        }

        static void Main(string[] args)
        {
            Application application = new Application();
            application.Init();
            application.Start();
        }
    }
}
