﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab6ForRefactoring.bnsit.patterns.model
{
    public class Painting : Equipment
    {
        public Painting() : base() { }

        public Painting(string signature, int cost, DateTime purchaseDate) : base(signature, cost, purchaseDate) { }
    }
}
