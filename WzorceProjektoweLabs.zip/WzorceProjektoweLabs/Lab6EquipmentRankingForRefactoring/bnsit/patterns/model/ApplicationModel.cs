﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;

namespace Lab6ForRefactoring.bnsit.patterns.model
{
    [XmlRoot]
    public class ApplicationModel
    {
        [XmlElement]
        public List<Building> Buildings;

        public ApplicationModel()
        {
            this.Buildings = new List<Building>();
        }

        public void AddBuilding(Building building)
        {
            Buildings.Add(building);
        }

        public string FindBuildingsNames()
        {
            string buildingsNames = "";

            foreach (var building in Buildings)
            {
                buildingsNames += building.Name + ", ";
            }

            return buildingsNames;
        }

        public Building FindBuilding(string name)
        {

            foreach (var building in Buildings)
            {
                if (building.Name.Equals(name))
                {
                    return building;
                }
            }

            throw new ApplicationException("There's no building named " + name);
        }

        public Elevation FindElevation(string buildingName, int elevationNo)
        {
            Elevation elevation = FindBuilding( buildingName ).GetElevation(elevationNo);

            if ( elevation == null )
            {
                throw new ApplicationException( "There's no elevation No: " + elevationNo + " in the building " + buildingName );
            }

            return elevation;
        }

        public Room FindRoom(string buildingName, int elevationNo, int roomNo)
        {
            Room room = FindElevation(buildingName, elevationNo).GetRoom(roomNo);

            if (room == null)
            {
                throw new ApplicationException("There's no room No: " + roomNo + " in the building " + buildingName + " on the elevation No: " + elevationNo);
            }

            return room;
        }

        public string FindElevationsNumbers(string buildingName)
        {
            Building building = FindBuilding(buildingName);

            string elevationsNumbers = "";
            foreach (Elevation elevation in building.Elevations)
            {
                elevationsNumbers += elevation.Number.ToString() + ", ";
            }

            return elevationsNumbers;

        }

        public string FindRoomsNumbers(string buildingName, int elevationNo)
        {
            Building buidling = FindBuilding(buildingName);
            Elevation elevation = buidling.GetElevation(elevationNo);

            string roomsNumbers = "";
            foreach (Room room in elevation.Rooms)
            {
                roomsNumbers += room.Number.ToString() + ", ";
            }

            return roomsNumbers;
        }

        public void Save(String fileName)
        {
            XmlSerializer serializer = new XmlSerializer(this.GetType());
            Stream outputStream = CreateOutputStream(fileName);
            serializer.Serialize(outputStream, this);
            outputStream.Close();
        }

        public void Load(String fileName)
        {
            XmlSerializer serializer = new XmlSerializer(this.GetType());
            Stream inputStream = CreateInputStream(fileName);
            ApplicationModel model = (ApplicationModel) serializer.Deserialize(inputStream);
            Buildings = model.Buildings;

            inputStream.Close();
        }

        private Stream CreateOutputStream(String fileName)
        {
            Stream stream = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None);

            return stream;
        }

        private Stream CreateInputStream(String fileName)
        {
            Stream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.None);

            return stream;
        }

    }
}
