﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lab3ForRefactoring.bnsit.patterns.model;
using Lab3ForRefactoring.bnsit.patterns.logic.report;
using Lab3ForRefactoring.bnsit.patterns.logic;
using Lab3ToRefactor;

namespace Lab3ForRefactoring.bnsit.patterns
{
    public class Application : Subscriber
    {
        private const String PROMPT = "ees>";
        private const String HELLO_MESSAGE = "Welcome to Equipment Evidence System!";

        private ApplicationModel model;

        private HelpSystemManager helpSystemManager;

        private CommandFactory commandFactory;

        private Boolean running = false;

        private Broker broker;

        public Application() 
        {
            this.model = new ApplicationModel();
            this.helpSystemManager = new HelpSystemManager();

            this.broker = new Broker();

            Dictionary<string, Command> commands = new Dictionary<string, Command>();
            HelloCommand helloCommand = new HelloCommand();
            commands["hello"] = helloCommand;

            LoadCommand loadCommand = new LoadCommand(this.model);
            commands["load"] = loadCommand;
            SaveCommand saveCommand = new SaveCommand(this.model);
            commands["save"] = saveCommand;

            commands["help"] = new HelpCommand(commands);
            commands["exit"] = new ExitCommand(this.broker);

            broker.Subscribe("started", loadCommand);
            broker.Subscribe("started", helloCommand);
            broker.Subscribe("exit", this);
            broker.Subscribe("exit", saveCommand);

            this.commandFactory = new CommandFactory(commands);
        }

        public void Stop()
        {
            running = false;
        }

        public void Start()
        {
            this.broker.Publish("started");
            
            running = true;

//            Console.WriteLine(HELLO_MESSAGE);

            while (running)
            {
                Console.Write(PROMPT);
                String commandString = Console.ReadLine();
                string[] commandParams = commandString.Split(' ');

                string commandName = commandParams[0];
                Command command = commandFactory.Create(commandName);
                command.Execute(commandParams);

                //if (command.Equals("hello"))
                //{
                //    Console.WriteLine(HELLO_MESSAGE);
                //}
                //else if (command.StartsWith("save"))
                //{
                //    String fileName = command.Split(' ')[1];
                //    model.Save(fileName);
                //}
                //else if (command.StartsWith("load"))
                //{
                //    String fileName = command.Split(' ')[1];
                //    model.Load(fileName);
                //}
                //else if (command.Equals("add_building"))
                //{
                //    addBuilidng();
                //}
                //else if (command.StartsWith("building_report"))
                //{
                //    String reportType = command.Split( ' ' )[1];

                //    BuildingsReportGenerator generator = createGenerator( reportType );

                //    Console.WriteLine( generator.Generate() );
                //}
                //else if (command.StartsWith("help")) {
                //    string[] commandAndParams = command.Split( ' ' );

                //    if (commandAndParams.Length == 1)
                //    {
                //        helpSystemManager.PrintAllHelp();
                //    }
                //    else
                //    {
                //        helpSystemManager.PrintHelp( commandAndParams[1] );
                //    }
                //}
                //else if (command.Equals("exit"))
                //{
                //    Stop();
                //}
            }
        }

        private BuildingsReportGenerator createGenerator(string reportType)
        {
            switch (reportType) {
                case "tree": return new TreeReportGenerator( model.Buildings );
                case "dashed": return new DahsedReportGenerator(model.Buildings);
                case "indented": return new IndentedReportGenerator( model.Buildings );
            }

            return null;
        }

        private void addBuilidng() {
            Console.Write("Name: "); ;
            string name = Console.ReadLine(); 
           
            Console.Write( "Address: " );
            string address = Console.ReadLine();

            BuildingBuilder builder = new BuildingBuilder();
            builder.BuildNewBuilding(name, address);

            Console.Write("First elevation No: ");
            int firstElevationNo = int.Parse(Console.ReadLine());

            Console.Write("Last elevation No: ");
            int lastElevationNo = int.Parse(Console.ReadLine());

            builder.AddEvevations(firstElevationNo, lastElevationNo);

            for (int i = firstElevationNo; i <= lastElevationNo; ++i)
            {
                Console.Write("How many room on elevation " + i + "?: ");
                int roomsNumber = int.Parse(Console.ReadLine());

                List<int> roomsNumbers = new List<int>();
                for (int j = 0; j < roomsNumber; ++j )
                {
                    Console.Write("Number of " + j + " room " + " of " + i + " elevation: ");
                    roomsNumbers.Add(int.Parse(Console.ReadLine()));
                }

                builder.AddRooms(i, roomsNumbers);
            }

            model.AddBuilding(builder.FinalBuilding);
        }

        static void Main(string[] args)
        {
            Application application = new Application();
            application.Start();
        }

        public void OnEvent(string type)
        {
            Stop();
        }
    }
}
