﻿using System;
namespace Lab3ToRefactor
{
    public interface Subscriber
    {
        void OnEvent(string type);
    }
}
