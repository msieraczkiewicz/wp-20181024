﻿using System.Collections.Generic;

namespace Lab3ForRefactoring.bnsit.patterns
{
    internal class HelpCommand : Command
    {
        private Dictionary<string, Command> commands;

        public HelpCommand(Dictionary<string, Command> commands)
        {
            this.commands = commands;
        }
    }
}