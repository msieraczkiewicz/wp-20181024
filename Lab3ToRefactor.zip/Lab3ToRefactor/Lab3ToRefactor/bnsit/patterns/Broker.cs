﻿using System.Collections.Generic;
using Lab3ToRefactor;

namespace Lab3ForRefactoring.bnsit.patterns
{
    public class Broker
    {
        private Dictionary<string, List<Subscriber>> subscribers 
                    = new Dictionary<string, List<Subscriber>>();
        
        public void Subscribe(string eventType, Subscriber subscriber)
        {
            if (!subscribers.ContainsKey(eventType)) 
            {
                this.subscribers[eventType] = new List<Subscriber>();
            }

            this.subscribers[eventType].Add(subscriber);
        }

        public void Publish(string eventType)
        {
            List<Subscriber> eventSubscribers = this.subscribers[eventType];
            foreach (Subscriber subscriber in eventSubscribers)
            {
                subscriber.OnEvent(eventType);
            }
        }
    }
}