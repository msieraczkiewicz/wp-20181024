﻿using System;
using System.Collections.Generic;

namespace Lab3ForRefactoring.bnsit.patterns
{
    internal class CommandFactory
    {
        private Dictionary<string, Command> commands;

        public CommandFactory(Dictionary<string, Command> commands)
        {
            this.commands = commands;
        }

        public Command Create(string commandName)
        {
            
            return commands[commandName];
        }
    }
}