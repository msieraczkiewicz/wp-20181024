﻿using System;
using System.Collections.Generic;
using Lab3ForRefactoring.bnsit.patterns.model;
using Lab3ToRefactor;

namespace Lab3ForRefactoring.bnsit.patterns
{
    public interface Command
    {
        void Execute(string[] parameters);
        string GetHelp();
    }

    public class HelloCommand : Command, Subscriber
    {
        private const string HELLO_MESSAGE = "Welcome to Equipment Evidence System!";

        public void Execute(string[] parameters)
        {
            Console.WriteLine(HELLO_MESSAGE);
        }

        public string GetHelp()
        {
            return "hello - Prints hello message.";
        }

        public void OnEvent(string eventType) {
            if (eventType.Equals("started"))
            {
                this.Execute(new string[] { });
            }
        }
    }

    public class LoadCommand : Command, Subscriber
    {
        private ApplicationModel model;

        public LoadCommand(ApplicationModel model)
        {
            this.model = model;
        }

        public void Execute(string[] parameters)
        {
            this.model.Load(parameters[1]);
        }

        public string GetHelp()
        {
            return "load - loads data from file (params: filename)";
        }

        public void OnEvent(string eventType)
        {
            if (eventType.Equals("started"))
            {
                this.Execute(new string[] { "default.xml" });
            }
        }
    }

    public class SaveCommand : Command, Subscriber
    {
        private ApplicationModel model;

        public SaveCommand(ApplicationModel model)
        {
            this.model = model;
        }

        public void Execute(string[] parameters)
        {
            this.model.Save(parameters[1]);
        }

        public string GetHelp()
        {
            return "save - saves data from file (params: filename)";
        }

        public void OnEvent(string eventType)
        {
            if (eventType.Equals("exit"))
            {
                this.Execute(new string[] { "default.xml" });
            }
        }
    }


    public class HelpCommand : Command
    {
        private Dictionary<string, Command> commands;

        public HelpCommand(Dictionary<string, Command> commands)
        {
            this.commands = commands;
        }

        public void Execute(string[] parameters)
        {
            if (parameters.Length == 1) {
                //print all
            }
            else
            {
                string commandName = parameters[1];
                Console.WriteLine(this.commands[commandName].GetHelp());
            }
        }

        public string GetHelp()
        {
            return "help - show commands help (params: [commandName])";
        }
    }

    public class ExitCommand : Command
    {
        private readonly Broker broker;

        public ExitCommand(Broker broker)
        {
            this.broker = broker;
        }


        public void Execute(string[] parameters)
        {
            this.broker.Publish("exit");
        }

        public string GetHelp()
        {
            return "exit - exits application";
        }
    }
}